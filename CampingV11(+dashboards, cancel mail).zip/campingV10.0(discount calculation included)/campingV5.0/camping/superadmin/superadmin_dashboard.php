<?php
session_start();
include '../db/db.php';

// Check if superadmin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login/index.php");
    exit();
}

// Handle role change requests
if (isset($_POST['change_role'])) {
    $userId = $_POST['user_id'];
    $newRole = $_POST['new_role'];
   
    try {
        $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->execute([$newRole, $userId]);
       
        $_SESSION['message'] = "User role updated successfully!";
        $_SESSION['message_type'] = "success";
    } catch (PDOException $e) {
        $_SESSION['message'] = "Error updating role: " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
    }
   
    header("Location: superadmin_dashboard.php");
    exit();
}

// Fetch all admins
$query = $conn->query("SELECT * FROM users WHERE role='admin'");
$admins = $query->fetchAll(PDO::FETCH_ASSOC);

// Fetch all clients
$clientQuery = $conn->query("SELECT * FROM users WHERE role='client'");
$clients = $clientQuery->fetchAll(PDO::FETCH_ASSOC);

// Count different statuses
$totalAdmins = count($admins);
$pendingAdmins = 0;
$activeAdmins = 0;

foreach ($admins as $admin) {
    if ($admin['status'] == 'pending') $pendingAdmins++;
    if ($admin['status'] == 'active') $activeAdmins++;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: url('../profile-icons/admin-background3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .sidebar {
            background: linear-gradient(to top, #19274A, #425C97);
            min-height: 100vh;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.8);
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 600;
            padding: 1rem;
        }
        .sidebar .nav-link:hover {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .sidebar .nav-link.active {
            color: #fff;
        }
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        .badge-pending {
            background-color: rgb(16, 202, 143);
            border-radius:5px;
        }
        .badge-active {
            background-color: #1cc88a;
            border-radius:5px;
        }
        .badge-deactivated {
            background-color: #e74a3b;
            border-radius:5px;
        }
        .badge-client {
            background-color: #6c757d;
            border-radius:5px;
        }
        .badge-admin {
            background-color: #007bff;
            border-radius:5px;
        }
        .add-location-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            font-size: 24px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .profile-dropdown-container {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .profile-button {
            background: none;
            cursor: pointer;
            width: 60px;
            height: 60px;
            padding: 0;
            border-radius: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transform: translate(-5px, -5px);
            border: 10px solid #425C97;
        }
        .profile-icon {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }
        .profile-icon:hover {
            filter: brightness(1.5);
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.8);
        }
        .profile-dropdown {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            min-width: 200px;
            text-align: center;
            border: 2px solid black;
            z-index: 1050;
        }
        .profile-dropdown p {
            font-size: 16px;
            margin-bottom: 10px;
        }
        .logout-btn {
            padding: 10px;
            background: linear-gradient(to top, #19274A, #425C97);
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
        }
        .logout-btn:hover {
            background: linear-gradient(to top, #19274A, #425C97);
        }
        .card {
            background: linear-gradient(to top, #19274A, #425C97);
            border: 2px solid rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(20px);
            color: white;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            font-weight:600;
            font-size:20px;
        }
        hr {
            border: 1px solid white;
        }
        h1 {
            color: white;
        }
        .message-alert {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse bg-primary">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h4 class="text-white">Super Admin Panel</h4>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="superadmin_dashboard.php">
                                <i class="fas fa-fw fa-tachometer-alt"></i>
                                Dashboard
                            </a>
                        </li><hr/>
                        <li class="nav-item">
                            <a class="nav-link" href="../dashboards/dashboard.html">
                                <i class="fas fa-fw fa-cog"></i>
                                dashboards
                            </a>
                        </li><hr/>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="message-alert alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
                        <?= $_SESSION['message'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
                <?php endif; ?>

                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1>User Account Management</h1>
                    <!-- Profile Dropdown Button -->
                    <div class="profile-dropdown-container">
                        <button class="profile-button" id="profile-button">
                            <img src="../profile-icons/super-admin-icon.png" alt="Profile Icon" class="profile-icon">
                        </button>
                       
                        <!-- Dropdown Menu -->
                        <div class="profile-dropdown" id="profile-dropdown">
                            <p id="username-display"><?php echo $_SESSION['username']; ?></p>
                            <form action="../logout/logout.php" method="post">
                                <button type="submit" name="logout" class="logout-btn">Logout</button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs">Total Admins</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalAdmins ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs">Pending Admins</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $pendingAdmins ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs">Active Admins</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $activeAdmins ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Admin Management Table -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h3 class="m-0">Admin Accounts</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="adminTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Role</th>
                                        <th>Registered At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($admins as $admin): ?>
                                    <tr>
                                        <td><?= $admin['id'] ?></td>
                                        <td><?= $admin['username'] ?></td>
                                        <td><?= $admin['email'] ?></td>
                                        <td>
                                            <span class="badge badge-<?= strtolower($admin['status']) ?>">
                                                <?= ucfirst($admin['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge badge-admin">Admin</span>
                                        </td>
                                        <td><?= date('M d, Y H:i', strtotime($admin['created_at'] ?? 'now')) ?></td>
                                        <td>
                                            <?php if ($admin['status'] == 'pending' || $admin['status'] == 'deactivated'): ?>
                                                <a href="manage_admin/activate.php?id=<?= $admin['id'] ?>" class="btn btn-success btn-sm action-btn">
                                                    <i class="fas fa-check"></i> Activate
                                                </a>
                                            <?php endif; ?>
                                            <?php if ($admin['status'] == 'active'): ?>
                                                <a href="manage_admin/deactivate.php?id=<?= $admin['id'] ?>" class="btn btn-primary btn-sm action-btn">
                                                    <i class="fas fa-times"></i> Deactivate
                                                </a>
                                            <?php endif; ?>
                                            
                                            <a href="manage_admin/delete.php?id=<?= $admin['id'] ?>" class="btn btn-danger btn-sm action-btn" onclick="return confirm('Are you sure you want to delete this admin?')">
                                                <i class="fas fa-trash"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Client Management Table -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h3 class="m-0">Client Accounts</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="clientTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Role</th>
                                        <th>Registered At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($clients as $client): ?>
                                    <tr>
                                        <td><?= $client['id'] ?></td>
                                        <td><?= $client['username'] ?></td>
                                        <td><?= $client['email'] ?></td>
                                        <td>
                                            <span class="badge badge-<?= strtolower($client['status']) ?>">
                                                <?= ucfirst($client['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge badge-client">Client</span>
                                        </td>
                                        <td><?= date('M d, Y H:i', strtotime($client['created_at'] ?? 'now')) ?></td>
                                        <td>
                                            <form method="post" style="display: inline;">
                                                <input type="hidden" name="user_id" value="<?= $client['id'] ?>">
                                                <input type="hidden" name="new_role" value="admin">
                                                <button type="submit" name="change_role" class="btn btn-info btn-sm" onclick="return confirm('Are you sure you want to make this client an admin?')">
                                                    <i class="fas fa-user-shield"></i> Make Admin
                                                </button>
                                            </form>
                                            <a href="../manage_admin/delete.php?id=<?= $client['id'] ?>" class="btn btn-danger btn-sm action-btn" onclick="return confirm('Are you sure you want to delete this client?')">
                                                <i class="fas fa-trash"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <script>
        // Toggle the dropdown menu visibility when the profile button is clicked
        document.getElementById("profile-button").addEventListener("click", function(event) {
            const dropdown = document.getElementById("profile-dropdown");
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
            event.stopPropagation();
        });

        // Close the dropdown menu if clicking outside
        document.addEventListener("click", function(event) {
            const dropdown = document.getElementById("profile-dropdown");
            const profileButton = document.getElementById("profile-button");
            if (!profileButton.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = "none";
            }
        });

        // Add confirmation for logout
        document.querySelector('.logout-btn').addEventListener('click', function(event) {
            const confirmed = confirm("Are you sure you want to log out?");
            if (!confirmed) {
                event.preventDefault();
            }
        });

        // Auto-hide alert messages after 5 seconds
        setTimeout(() => {
            const alert = document.querySelector('.message-alert');
            if (alert) {
                alert.style.display = 'none';
            }
        }, 5000);
    </script>
    <script src="../js/gsap.min.js"></script>
    <script>
        gsap.from('.sidebar',1.2, {opacity: 1, x:-300, delay: 0})
        gsap.from('.card',1.2, {opacity: 0, y:-50, delay: .5})
    </script>
</body>
</html>