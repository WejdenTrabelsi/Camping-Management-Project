<?php
include '../../db/db.php';
$id = $_GET['id'];
$conn->query("DELETE FROM users WHERE id=$id");
header("Location: ../superadmin_dashboard.php");
?>
