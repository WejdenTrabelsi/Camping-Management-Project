<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login/index.php");
    exit;
}

// Get location ID and date from POST request
if (!isset($_POST['date']) || !isset($_POST['location_id'])) {
    echo json_encode(['success' => false, 'message' => 'Missing date or location ID']);
    exit;
}

$date = $_POST['date'];
$location_id = $_POST['location_id'];

// Insert into blocked-dates table
$stmt = $conn->prepare("INSERT INTO blocked_dates (date, location_id) VALUES (?, ?)");
$stmt->execute([$date, $location_id]);

echo json_encode(['success' => true, 'message' => 'Date successfully blocked']);
?>
