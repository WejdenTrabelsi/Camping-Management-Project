<?php
// mark_as_read.php
session_start();
require '../db/db.php'; // Include your database connection file

if (isset($_SESSION['user_id']) && isset($_POST['notification_id'])) {
    $user_id = $_SESSION['user_id'];
    $notification_id = $_POST['notification_id'];

    // Insert the notification into the user_notifications table with is_read = 1 and is_deleted = 0
    $stmt = $conn->prepare("INSERT INTO user_notifications (user_id, notification_id, is_read, is_deleted) VALUES (?, ?, 1, 0)");
    $stmt->execute([$user_id, $notification_id]);

    // Return success response
    echo json_encode(['success' => true]);
} else {
    // If the user is not logged in or no notification_id is provided, return failure
    echo json_encode(['success' => false]);
}

