<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include '../../db/db.php';

// 1. Validate request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['signup_message'] = "Invalid request method";
    header("Location: admin-signup.php");
    exit();
}

// 2. Collect and sanitize inputs
$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
$role = 'admin';
$gender = $_POST['gender'] ?? 'female';
$age = $_POST['age'] ?? '';
$city = trim($_POST['selected_city'] ?? ''); // Governorate field

// 3. Validation checks
$errors = [];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format";
if (strlen($username) < 4) $errors[] = "Username must be at least 4 characters";
if (strlen($password) < 8) $errors[] = "Password must be at least 8 characters";
if (!in_array($gender, ['male', 'female'])) $errors[] = "Invalid gender selection.";
if (!is_numeric($age) || $age < 18 || $age > 100) $errors[] = "Age must be between 18 and 100.";
if (empty($city)) $errors[] = "Please select your governorate (city).";

if (!empty($errors)) {
    $_SESSION['signup_message'] = implode("<br>", $errors);
    header("Location: admin-signup.php");
    exit();
}

// 4. Check for existing email
try {
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        $_SESSION['signup_message'] = "Email already registered";
        header("Location: admin-signup.php");
        exit();
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $_SESSION['signup_message'] = "System error. Please try later.";
    header("Location: admin-signup.php");
    exit();
}

// 5. Create user and profile
try {
    $conn->beginTransaction();

    
    // Insert into users table
    $stmt = $conn->prepare("INSERT INTO users (id ,email, username, password ,role, gender, age, city) VALUES (?, ?, ?, ?, ?,?,?,?)");
    $stmt->execute([$userId, $email, $username, $password,$role,$gender, $age, $city]);

    $conn->commit();

    $_SESSION['signup_message'] = "Registration successful! Awaiting super-admin activation.";
    header("Location: admin-signup.php");
    exit();
} catch (Exception $e) {
    $conn->rollBack();
    die("SIGNUP ERROR: " . $e->getMessage());
    $_SESSION['signup_message'] = "Registration failed. Please try again.";
    header("Location: admin-signup.php");
    exit();
}
