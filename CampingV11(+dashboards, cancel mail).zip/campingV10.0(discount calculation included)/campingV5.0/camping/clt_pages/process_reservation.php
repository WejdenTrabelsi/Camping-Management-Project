<?php
session_start();
require_once '../db/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $location_id = $_POST['location_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $payment_method = $_POST['payment_method'];

    // Get number of adults and kids
    $num_adults = isset($_POST['solid_number_adults']) ? (int)$_POST['solid_number_adults'] : 1;
    $num_kids = isset($_POST['solid_number_kids']) ? (int)$_POST['solid_number_kids'] : 0;

    try {
        $stmt = $conn->prepare("SELECT price FROM locations WHERE id = ?");
        $stmt->execute([$location_id]);
        $location = $stmt->fetch();
        $price_per_day = $location['price'];

        $datetime1 = new DateTime($start_date);
        $datetime2 = new DateTime($end_date);
        $interval = $datetime1->diff($datetime2);
        $days = max(1, $interval->days);

        $total_price = ($num_adults + $num_kids) * $price_per_day * $days;

        // 👇 Include adults and kids in the INSERT query
        $stmt = $conn->prepare("
            INSERT INTO reservations (user_id, location_id, start_date, end_date, total_price, status, adults, kids, payment_method) 
            VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?)
        ");
        $stmt->execute([
            $user_id, $location_id, $start_date, $end_date, $total_price, $num_adults, $num_kids, $payment_method
        ]);

        $_SESSION['reservation_success'] = true;
        header("Location: my_reservations.php");
        exit;

    } catch (PDOException $e) {
        $_SESSION['error'] = "Error creating reservation: " . $e->getMessage();
        header("Location: reserve.php?location_id=$location_id");
        exit;
    }
} else {
    header("Location: locations.php");
    exit;
}
?>
