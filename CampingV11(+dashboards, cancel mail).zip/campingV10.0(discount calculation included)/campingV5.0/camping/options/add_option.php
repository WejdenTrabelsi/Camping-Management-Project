<?php
session_start();
include "../db/config.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    // Insert the new option into the database
    $stmt = $conn->prepare("INSERT INTO extra_options (name, description, price) VALUES (?, ?, ?)");
    $stmt->bind_param("ssd", $name, $description, $price);

    if ($stmt->execute()) {
        // Set the success message and redirect to manage_option.php
        $_SESSION['success_message'] = 'Option added successfully!';
        header("Location: ../options/manage_option.php");
        exit; // Make sure to stop further execution
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Option</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
    <div class="card">
        <div class="card-header">
            <h4>Add New Option</h4>
        </div>
        <div class="card-body">
            <form action="../options/add_option.php" method="POST">
                <div class="mb-3">
                    <label for="name" class="form-label">Option Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Option Name" required>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" placeholder="Option Description" required></textarea>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Price</label>
                    <input type="number" class="form-control" id="price" name="price" min="0" step="0.01" placeholder="Price" required>
                </div>

                <button type="submit" class="btn btn-primary">Add Option</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
