<?php
session_start();
require_once '../db/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/index.php");
    exit;
}


// Initialize variables
$location = [];
$extra_options = [];
$services_only = false;
$location_id = $_GET['location_id'] ?? $_POST['location_id'] ?? null;

$blocked_dates = [];
if ($location_id) {
    $stmt = $conn->prepare("SELECT date FROM blocked_dates WHERE location_id = ?");
    $stmt->execute([$location_id]);
    $blocked_dates = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch location details if ID is present
if ($location_id) {
    $stmt = $conn->prepare("SELECT * FROM locations WHERE id = ?");
    $stmt->execute([$location_id]);
    $location = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$location) {
        header("Location: locations.php");
        exit;
    }
    
    // Fetch options related to this location
    $stmt = $conn->prepare("SELECT * FROM location_options WHERE location_id = ?");
    $stmt->execute([$location_id]);
    $extra_options = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Calculate total price (initial load)
$total_price = 0;
if (isset($_POST['services'])) {
    foreach ($_POST['services'] as $service) {
        $service_data = json_decode($service, true);
        $total_price += $service_data['price'];
    }
}

if (!$services_only && $location) {
    $total_price += $location['price'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make a Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">


    <style>
        body {
            background-image: url('../profile-icons/admin-background3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        label, h1, .price-display {
            color: white;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.7);
        }
        .container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .form-section {
            width: 100%;
            max-width: 650px;
        }
        .card {
            background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));
            backdrop-filter: blur(5px);
            border: 2.5px solid white;
            border-radius: 20px;
        }
        .card-header {
            background: linear-gradient(to top, #19274A, #425C97) !important;
            color: white;
            border-bottom: 2.5px solid white;
            border-top-right-radius: 20px;
            border-top-left-radius: 20px;
        }
        .form-check-label {
            color: white;
        }
       


    </style>
</head>
<body>
<div class="container py-4">
    <div class="card form-section shadow">
        <div class="card-header" style="border-top-left-radius:20px;border-top-right-radius:20px">
            <h4 class="mb-0">
                <i class="fas fa-calendar-check me-2"></i>
                <?= $services_only ? 'Book Services Only' : 'Reserve ' . htmlspecialchars($location['name'] ?? '') ?>
            </h4>
        </div>
        <div class="card-body">
        <form id="reservationForm" action="process_reservation.php" method="POST">
            <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?>">
            <input type="hidden" name="location_id" value="<?= $location['id'] ?>">
            
            <!-- Date inputs -->
            <div class="mb-3">
                <label for="start_date" class="form-label">Check-in Date</label>
                <input type="date" class="form-control" id="start_date" name="start_date" required min="<?= date('Y-m-d') ?>">
            </div>
            
            <div class="mb-3">
                <label for="end_date" class="form-label">Check-out Date</label>
                <input type="date" class="form-control" id="end_date" name="end_date" required min="<?= date('Y-m-d') ?>">
            </div>

            <!-- Adults and Kids -->
            <div class="mb-3" style="text-align: center;">
                <div style="display: flex; justify-content: center; gap: 10px; margin-top: 10px;">
                    <div style="display: flex; flex-direction: column; align-items: center;">
                        <label for="adults" class="form-label">Adults</label>
                        <input type="number" id="adults" class="form-control" name="solid_number_adults" min="1" step="1" placeholder="1" style="width: 150px;" required>
                    </div>
                    <div style="display: flex; flex-direction: column; align-items: center;">
                        <label for="kids" class="form-label">Kids (under 18)</label>
                        <input type="number" id="kids" class="form-control" name="solid_number_kids" min="0" step="1" placeholder="0" style="width: 150px;">
                    </div>
                </div>
            </div>

            <!-- Payment method -->
            <div class="mb-3">
                <label for="payment_method" class="form-label">Payment Method</label>
                <select class="form-select" id="payment_method" name="payment_method" required>
                    <option value="credit_card">Credit Card</option>
                    <option value="paypal">PayPal</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="cash_on_arrival">Cash on Arrival</option>
                </select>
            </div>

            <!-- Price display -->
            <div class="mb-3 price-display">
                <h4>Total Price: $<span id="totalPrice"><?= number_format($total_price, 2) ?></span></h4>
            </div>

            <!-- Submit -->
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-calendar-check"></i> Confirm Reservation
                </button>
                <a href="location.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
        </div>
    </div>
</div>

<!-- JS Script -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    // Get blocked dates from PHP and pass them to JavaScript
    const blockedDates = <?= json_encode(array_column($blocked_dates, 'date')) ?>;
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
    flatpickr("#start_date", {
        dateFormat: "Y-m-d",
        disable: blockedDates,  // Disable blocked dates
        onChange: function(selectedDates, dateStr, instance) {
            // Update the minimum date for the check-out field
            const startDate = selectedDates[0];
            const endDateInput = document.getElementById('end_date');
            endDateInput.min = dateStr;
            if (new Date(endDateInput.value) < startDate) {
                endDateInput.value = '';
            }
        }
    });

    flatpickr("#end_date", {
        dateFormat: "Y-m-d",
        disable: blockedDates,  // Disable blocked dates
    });
});
flatpickr("#start_date", {
    dateFormat: "Y-m-d",
    disable: blockedDates,
    onDayCreate: function(dObj, dStr, instance) {
        const dateStr = instance.formatDate(dObj, "Y-m-d");
        if (blockedDates.includes(dateStr)) {
            dObj.classList.add("blocked-date");
        }
    }
});

flatpickr("#end_date", {
    dateFormat: "Y-m-d",
    disable: blockedDates,
    onDayCreate: function(dObj, dStr, instance) {
        const dateStr = instance.formatDate(dObj, "Y-m-d");
        if (blockedDates.includes(dateStr)) {
            dObj.classList.add("blocked-date");
        }
    }
});

    const pricePerNight = <?= $location['price'] ?? 0 ?>;

    function calculateTotal() {
        const adults = parseInt(document.getElementById('adults').value) || 0;
        const kids = parseInt(document.getElementById('kids').value) || 0;
        const start = document.getElementById('start_date').value;
        const end = document.getElementById('end_date').value;

        let days = 1;
        if (start && end) {
            const startDate = new Date(start);
            const endDate = new Date(end);
            const diff = endDate - startDate;
            days = Math.ceil(diff / (1000 * 60 * 60 * 24));
            if (days <= 0) days = 1;
        }

        const total = (adults + kids) * days * pricePerNight;
        document.getElementById('totalPrice').textContent = total.toFixed(2);
    }

    ['start_date', 'end_date', 'adults', 'kids'].forEach(id => {
        document.getElementById(id).addEventListener('input', calculateTotal);
    });

    document.getElementById('start_date')?.addEventListener('change', function() {
        const startDate = this.value;
        const endDateInput = document.getElementById('end_date');
        endDateInput.min = startDate;
        if (endDateInput.value < startDate) {
            endDateInput.value = '';
        }
    });
    
document.getElementById('reservationForm').addEventListener('submit', function(event) {
    const startDateStr = document.getElementById('start_date').value;
    const endDateStr = document.getElementById('end_date').value;

    if (!startDateStr || !endDateStr) {
        return; // No dates selected yet
    }

    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);

    // Create a Set for faster lookup
    const blockedSet = new Set(blockedDates);

    // Check each date between start and end
    let currentDate = new Date(startDate);
    while (currentDate <= endDate) {
        const currentStr = currentDate.toISOString().split('T')[0]; // Format as 'YYYY-MM-DD'

        if (blockedSet.has(currentStr)) {
            event.preventDefault(); // Stop form from submitting
            alert('A blocked date is included in your reservation. Please choose other dates.');
            return;
        }
        
        // Move to the next day
        currentDate.setDate(currentDate.getDate() + 1);
    }
});


</script>


</body>
</html>
