<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login/index.php");
    exit;
}

// Get location ID from URL
if (!isset($_GET['id'])) {
    header("Location: locations.php");
    exit;
}

$location_id = $_GET['id'];
// Fetch location
$stmt = $conn->prepare("SELECT * FROM locations WHERE id = ?");
$stmt->execute([$location_id]);
$location = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$location) {
    header("Location: locations.php");
    exit;
}

// Fetch location capacity
$capacityQuery = $conn->prepare("SELECT capacity FROM locations WHERE id = ?");
$capacityQuery->execute([$location_id]);
$locationCapacity = $capacityQuery->fetch();
$capacity = $locationCapacity['capacity'] ?? 0;

// Fetch reservations for this location
$reservationsQuery = $conn->prepare("SELECT * FROM reservations WHERE location_id = ?");
$reservationsQuery->execute([$location_id]);
$reservations = $reservationsQuery->fetchAll(PDO::FETCH_ASSOC);

// Prepare an array to track people per day
$occupancy = [];
foreach ($reservations as $reservation) {
    $start = new DateTime($reservation['start_date']);
    $end = new DateTime($reservation['end_date']);
    $people = $reservation['adults'] + $reservation['kids'];
    
    while ($start <= $end) {
        $day = $start->format('Y-m-d');
        if (!isset($occupancy[$day])) {
            $occupancy[$day] = 0;
        }
        $occupancy[$day] += $people;
        $start->modify('+1 day');
    }
}

// Handle month/year from URL, otherwise use current
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

// Adjust if month goes out of range
if ($month < 1) {
    $month = 12;
    $year--;
}
if ($month > 12) {
    $month = 1;
    $year++;
}

// Number of days in the month
$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);

// Previous and next month calculations
$prevMonth = $month - 1;
$prevYear = $year;
if ($prevMonth < 1) {
    $prevMonth = 12;
    $prevYear--;
}

$nextMonth = $month + 1;
$nextYear = $year;
if ($nextMonth > 12) {
    $nextMonth = 1;
    $nextYear++;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Location Calendar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
         body {
            background-image: url('../profile-icons/admin-background3.jpg'); 
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
        }
         label {
            color: white;
         }
        .container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .calendar {
            display: flex;
            flex-wrap: wrap;
            width: 350px;
            margin-top: 20px;
            margin-left: 12px;
            margin: 20px auto;
        }
        .calendar-day {
            width: 50px; 
            height: 50px; 
            margin: 3px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            border-radius: 7px;
            font-weight: bold;
            font-family: sans-serif;
            cursor: pointer;
            color: black;
            border:3px solid;
        }
        .calendar-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
        }
        .calendar-nav a {
            color: white;
            font-size: 24px;
            text-decoration: none;
            padding: 0 20px;
        }
        .calendar-nav span {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }

        .day-menu {
            position: absolute;
            background-color: #fff;
            border-radius: 5px;
            border:2px solid;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: none;
            z-index: 100;
        }
    </style>
</head>
<body>
    
    <div class="container py-4">
        <div class="card shadow" style="background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57)); backdrop-filter:blur(5px);border:2.5px solid white;border-radius:20px;">
            <div class="card-header bg-primary text-white" style="background:linear-gradient(to top, #19274A, #425C97) !important;border-bottom:2.5px solid white;border-top-right-radius:20px;border-top-left-radius:20px;display: flex; justify-content: space-between; align-items: center">
                <h4 class="mb-0"><i class="fas fa-calendar me-2"></i> <?= htmlspecialchars($location['name']) ?> Calendar</h4>
                <a href="locations.php" class="btn btn-secondary me-2" style="background:linear-gradient(to top, #19274A, #425C97) !important; border:2px solid white;">
                             Go back
                        </a>
            </div>
            <div class="card-body">
                <div class="calendar-nav">
                    <a href="?id=<?php echo $location_id; ?>&month=<?php echo $prevMonth; ?>&year=<?php echo $prevYear; ?>"><i class="fas fa-chevron-left"></i></a>
                    <span><?php echo date('F Y', strtotime("$year-$month-01")); ?></span>
                    <a href="?id=<?php echo $location_id; ?>&month=<?php echo $nextMonth; ?>&year=<?php echo $nextYear; ?>"><i class="fas fa-chevron-right"></i></a>
                </div>
                <div class="calendar">
                    <?php
                    function getColor($percentage, $overCapacity) {
                        if ($overCapacity) {
                            return '#0E4CA1'; // Overcapacity color
                        }
                        if ($percentage == 0) {
                            return '#ffffff'; // White
                        } elseif ($percentage <= 25) {
                            return '#90CAF9';
                        } elseif ($percentage <= 50) {
                            return '#42A5F5';
                        } elseif ($percentage <= 75) {
                            return '#1E88E5';
                        } else {
                            return '#0E4CA1';
                        }
                    }

                    for ($day = 1; $day <= $daysInMonth; $day++) {
                        $date = sprintf('%04d-%02d-%02d', $year, $month, $day);
                        $people = $occupancy[$date] ?? 0;
                        $percentage = ($capacity > 0) ? ($people / $capacity) * 100 : 0;
                        $overCapacity = ($people > $capacity);

                        $color = getColor($percentage, $overCapacity);
                        
                        echo "<div class='calendar-day' style='background-color: $color; position: relative;' title='Occupancy: $people / $capacity' onclick='openMenu(event, \"$date\", $people, $capacity)'>
                            $day";
                        if ($overCapacity) {
                            echo "<i class='fas fa-exclamation-triangle' style='color:rgb(253, 253, 253); font-size: 12px; position: absolute; top: 3px; right: 3px;'></i>";
                        }
                        echo "</div>";
                    }
                    ?>
                </div>

                <!-- LEGEND STARTS HERE -->
                <div class="mt-4 p-3 rounded" style="background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57)); border: 2px solid white;">
                    <h6 class="text-white mb-3 text-center"><i class="fas fa-info-circle me-2"></i>occupancy levels</h6>
                    <div class="d-flex flex-wrap" style="gap:10px;">
                        
                        <div class="d-flex align-items-center">
                            <div style="width: 20px; height: 20px; background-color: #90CAF9; border: 1px solid black;border-radius:50%; margin-right: 8px;"></div>
                            <span class="text-white"> 1%--25%</span>
                        </div>
                        <div class="d-flex align-items-center">
                            <div style="width: 20px; height: 20px; background-color: #42A5F5; border: 1px solid black;border-radius:50%; margin-right: 8px;"></div>
                            <span class="text-white">26%--50%</span>
                        </div>
                        <div class="d-flex align-items-center">
                            <div style="width: 20px; height: 20px; background-color: #1E88E5; border: 1px solid black;border-radius:50%; margin-right: 8px;"></div>
                            <span class="text-white">51%--75%</span>
                        </div>
                        <div class="d-flex align-items-center">
                            <div style="width: 20px; height: 20px; background-color: #0E4CA1; border: 1px solid black;border-radius:50%;margin-right: 8px;"></div>
                            <span class="text-white">76%--100%</span>
                        </div>
                        <div class="d-flex align-items-center">
                            <div style="width: 20px; height: 25px; margin-right: 8px;"><i class="fas fa-exclamation-triangle" style="color:rgb(253, 253, 253);"></i></div>
                            <span class="text-white">over occupied</span>
                        </div>

                    </div>
                </div>
                <!-- LEGEND ENDS HERE -->
            </div>
        </div>
    </div>
    

    <div id="dayMenu" class="day-menu">
        <p id="menuDate"></p>
        <p id="menuOccupancy"></p>
        <button id="menuButton" class="btn btn-primary" style="background:linear-gradient(to top, #19274A, #425C97);border:1px solid white;">block this date</button>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/gsap.min.js"></script>
    <script>
        gsap.from('.container', 1.2, {opacity: 0, y: -50, delay: .2})
        gsap.from('input', 1.2, {opacity: 0, y: -50, delay: .7})
        gsap.from('img', 1.2, {opacity: 0, y: -50, delay: .7})
        gsap.from('label', 1.2, {opacity: 0, y: -50, delay: .4})
        gsap.from('textarea', 1.2, {opacity: 0, y: -50, delay: .7})
        gsap.from('select', 1.2, {opacity: 0, y: -50, delay: .7})
        gsap.from('button', 1.2, {opacity: 0, y: -50, delay: .9})
        gsap.from('a', 1.2, {opacity: 0, y: -50, delay: .9})

        function openMenu(event, date, people, capacity) {
            var menu = document.getElementById("dayMenu");
            var menuDate = document.getElementById("menuDate");
            var menuOccupancy = document.getElementById("menuOccupancy");
            
            menuDate.innerText = "Date: " + date;
            menuOccupancy.innerText = "Occupancy: " + people + "/" + capacity;

            menu.style.display = "block";
            menu.style.top = event.pageY + "px";
            menu.style.left = event.pageX + "px";
            
        }
        document.getElementById('menuButton').addEventListener('click', function () {
    var selectedDate = document.getElementById("menuDate").innerText.split(": ")[1];
    var locationId = <?php echo json_encode($location_id); ?>; // Location ID from PHP
    
    // Send AJAX request to PHP file
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "block_date.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    // Send data in format: date=selectedDate&location_id=locationId
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var response = JSON.parse(xhr.responseText);
            if (response.success) {
                alert(response.message);
            } else {
                alert(response.message);
            }
        }
    };
    xhr.send("date=" + encodeURIComponent(selectedDate) + "&location_id=" + locationId);
});

        // Close menu if clicked anywhere else
        window.addEventListener("click", function(event) {
            if (!event.target.closest(".calendar-day") && !event.target.closest("#dayMenu")) {
                document.getElementById("dayMenu").style.display = "none";
            }
        });
    </script>
</body>
</html>
