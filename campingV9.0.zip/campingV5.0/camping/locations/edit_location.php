<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login/index.php");
    exit;
}

// Get location ID
$location_id = $_GET['id'] ?? $_POST['id'] ?? null;
if (!$location_id) {
    header("Location: locations.php");
    exit;
}

// Fetch location
$stmt = $conn->prepare("SELECT * FROM locations WHERE id = ?");
$stmt->execute([$location_id]);
$location = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$location) {
    header("Location: locations.php");
    exit;
}

// Fetch all extra options
$stmt = $conn->query("SELECT id, name, description FROM extra_options");
$options = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch selected options
$stmt = $conn->prepare("SELECT option_name FROM location_options WHERE location_id = ?");
$stmt->execute([$location_id]);
$selectedOptions = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $type = $_POST['type'];
    $price = $_POST['price'];
    $capacity = $_POST['capacity'];
    $electricity = isset($_POST['electricity']) ? 1 : 0;
    $water = isset($_POST['water']) ? 1 : 0;
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];
    $current_image = $_POST['current_image'];

    // Upload image if new one provided
    if ($image) {
        $targetDir = "../uploads/";
        $targetFile = $targetDir . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $targetFile);
    } else {
        $targetFile = $current_image;
    }

    // Update location
    $stmt = $conn->prepare("UPDATE locations SET name = ?, type = ?, price = ?, capacity = ?, electricity = ?, water = ?, description = ?, image_path = ? WHERE id = ?");
    $success = $stmt->execute([$name, $type, $price, $capacity, $electricity, $water, $description, $targetFile, $location_id]);

    if ($success) {
        // Update extra options
        $selectedOptions = $_POST['extra_options'] ?? [];

        // Delete all old options
        $stmt = $conn->prepare("DELETE FROM location_options WHERE location_id = ?");
        $stmt->execute([$location_id]);

        // Insert selected ones
        foreach ($selectedOptions as $option_name) {
            $stmt = $conn->prepare("INSERT INTO location_options (location_id, option_name) VALUES (?, ?)");
            $stmt->execute([$location_id, $option_name]);
        }

        header("Location: locations.php?success=1");
        exit;
    } else {
        echo "Error updating location.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Location</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
         body {
            background-image: url('../profile-icons/admin-background3.jpg'); 
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
        }
         label{
            color:white;
         }
       
        .container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="card shadow" style="background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57)); backdrop-filter:blur(5px);border:2.5px solid white;border-radius:20px;">
            <div class="card-header bg-primary text-white" style="background:linear-gradient(to top, #19274A, #425C97) !important;border-bottom:2.5px solid white;border-top-right-radius:20px;border-top-left-radius:20px;">
                <h4 class="mb-0"><i class="fas fa-edit me-2"></i> Edit Location</h4>
            </div>
            <div class="card-body">
                <form action="edit_location.php?id=<?= $location['id'] ?>" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?= $location['id'] ?>">
                    <input type="hidden" name="current_image" value="<?= $location['image_path'] ?>">

                    <div class="mb-3">
                        <?php if ($location['image_path']): ?>
                            <label class="form-label" style="display: block;text-align: center;margin-bottom:-10px;font-size:25px;font-weight:600;">Current Image</label><br>
                            <img src="<?= htmlspecialchars($location['image_path']) ?>" class="img-thumbnail mb-2" style="max-height: 200px; display: block; margin: 0 auto;">
                        <?php endif; ?>
                        <label for="image" class="form-label" style="display: block;text-align: center;margin-top:15px;">
                            <?= $location['image_path'] ? 'Replace Image' : 'Upload Image' ?>
                        </label>
                        <input class="form-control" type="file" id="image" name="image" accept="image/*">
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="name" class="form-label">Location Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($location['name']) ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="type" class="form-label">Location Type</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="tent" <?= $location['type'] == 'tent' ? 'selected' : '' ?>>Tent Spot</option>
                                <option value="caravan" <?= $location['type'] == 'caravan' ? 'selected' : '' ?>>Caravan Spot</option>
                                <option value="chalet" <?= $location['type'] == 'chalet' ? 'selected' : '' ?>>Chalet</option>
                                <option value="rv" <?= $location['type'] == 'rv' ? 'selected' : '' ?>>RV Spot</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="price" class="form-label">Price per night ($)</label>
                            <input type="number" class="form-control" id="price" name="price" min="0" step="0.01" value="<?= $location['price'] ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label for="capacity" class="form-label">Maximum Capacity</label>
                            <input type="number" class="form-control" id="capacity" name="capacity" min="1" value="<?= $location['capacity'] ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Amenities</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="electricity" name="electricity" value="1" <?= $location['electricity'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="electricity">
                                    <i class="fas fa-bolt me-1" style="color:rgb(252, 197, 33);"></i> Electricity
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="water" name="water" value="1" <?= $location['water'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="water">
                                    <i class="fas fa-tint me-1" style="color:#10B6DD;"></i> Water
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($location['description']) ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Select Extra Options:</label><br>
                        <?php foreach ($options as $option): ?>
                            <div class="form-check form-check-inline" data-bs-toggle="tooltip" data-bs-placement="top" title="<?= htmlspecialchars($option['description']) ?>">
                                <input class="form-check-input" type="checkbox" id="option<?= $option['id'] ?>" name="extra_options[]" value="<?= $option['name'] ?>" <?= in_array($option['name'], $selectedOptions) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="option<?= $option['id'] ?>">
                                    <?= htmlspecialchars($option['name']) ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="locations.php" class="btn btn-secondary me-2" style="background:linear-gradient(to top, #19274A, #425C97) !important; border:2px solid white;">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                        <a href="discount/add-discount.php?id=<?= $location['id'] ?>" class="btn btn-secondary me-2" style="background:linear-gradient(to top, #19274A, #425C97) !important; border:2px solid white;">
                            <i class="fas fa-tags me-1"></i> Add Discount
                        </a>
                        <button type="submit" class="btn btn-primary" style="background:linear-gradient(to top, #19274A, #425C97) !important; border:2px solid white;">
                            <i class="fas fa-save me-1"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/gsap.min.js"></script>
    <script>
        gsap.from('.container', 1.2, {opacity: 0, y: -50, delay: .2})
        gsap.from('input', 1.2, {opacity: 0, y: -50, delay: .7})
        gsap.from('img', 1.2, {opacity: 0, y: -50, delay: .7})
        gsap.from('label', 1.2, {opacity: 0, y: -50, delay: .4})
        gsap.from('textarea', 1.2, {opacity: 0, y: -50, delay: .7})
        gsap.from('select', 1.2, {opacity: 0, y: -50, delay: .7})
        gsap.from('button', 1.2, {opacity: 0, y: -50, delay: .9})
        gsap.from('a', 1.2, {opacity: 0, y: -50, delay: .9})
    </script>
</body>
</html>
