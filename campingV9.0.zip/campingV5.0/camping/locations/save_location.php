<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login/index.php");
    exit;
}

// Get current user ID
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->execute([$_SESSION['username']]);
$user = $stmt->fetch();

// Retrieve form data
$location_name = $_POST['name'];
$location_type = $_POST['type'];
$location_price = $_POST['price'];
$location_capacity = $_POST['capacity'];
$location_electricity = isset($_POST['electricity']) ? 1 : 0;
$location_water = isset($_POST['water']) ? 1 : 0;
$location_description = $_POST['description'];

// Handle image upload
$image_path = null;
if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
    $upload_dir = '../uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    $image_name = time() . "_" . basename($_FILES['image']['name']);
    $image_path = $upload_dir . $image_name;

    if (!move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
        echo "Error uploading image.";
        exit;
    }
}

// Check if we are updating an existing location or adding a new one
if (isset($_POST['location_id']) && !empty($_POST['location_id'])) {
    // Editing an existing location
    $location_id = $_POST['location_id'];

    // Update location in the database
    $stmt = $conn->prepare("UPDATE locations 
                            SET name = :name, type = :type, price = :price, capacity = :capacity, 
                                electricity = :electricity, water = :water, description = :description, 
                                image_path = :image_path
                            WHERE id = :location_id");

    $stmt->bindParam(':location_id', $location_id);
    $stmt->bindParam(':name', $location_name);
    $stmt->bindParam(':type', $location_type);
    $stmt->bindParam(':price', $location_price);
    $stmt->bindParam(':capacity', $location_capacity);
    $stmt->bindParam(':electricity', $location_electricity);
    $stmt->bindParam(':water', $location_water);
    $stmt->bindParam(':description', $location_description);
    $stmt->bindParam(':image_path', $image_path);

    if ($stmt->execute()) {
        // Delete previous extra options
        $stmt_delete_opt = $conn->prepare("DELETE FROM location_options WHERE location_id = :location_id");
        $stmt_delete_opt->bindParam(':location_id', $location_id);
        $stmt_delete_opt->execute();

        // Insert new extra options if selected
        if (!empty($_POST['extra_options'])) {
            foreach ($_POST['extra_options'] as $option_id) {
                $stmt_opt = $conn->prepare("SELECT name FROM extra_options WHERE id = :option_id");
                $stmt_opt->bindParam(':option_id', $option_id);
                $stmt_opt->execute();
                $option = $stmt_opt->fetch(PDO::FETCH_ASSOC);

                if ($option) {
                    $stmt_insert_opt = $conn->prepare("INSERT INTO location_options (location_id, option_name) 
                                                       VALUES (:location_id, :option_name)");
                    $stmt_insert_opt->bindParam(':location_id', $location_id);
                    $stmt_insert_opt->bindParam(':option_name', $option['name']);
                    $stmt_insert_opt->execute();
                }
            }
        }

    // Set success message for editing
    $_SESSION['edit_message'] = "Location edited successfully!";
    header("Location: locations.php"); // Redirect to locations page
    exit;
    } else {
        echo "Error: Could not update location.";
    }
} else {
    // Adding a new location
    // Insert location into the database
    $stmt = $conn->prepare("INSERT INTO locations (name, type, price, capacity, electricity, water, description, image_path, created_by) 
                            VALUES (:name, :type, :price, :capacity, :electricity, :water, :description, :image_path, :created_by)");

    $stmt->bindParam(':name', $location_name);
    $stmt->bindParam(':type', $location_type);
    $stmt->bindParam(':price', $location_price);
    $stmt->bindParam(':capacity', $location_capacity);
    $stmt->bindParam(':electricity', $location_electricity);
    $stmt->bindParam(':water', $location_water);
    $stmt->bindParam(':description', $location_description);
    $stmt->bindParam(':image_path', $image_path);
    $stmt->bindParam(':created_by', $user['id']);

    if ($stmt->execute()) {
        $location_id = $conn->lastInsertId();

        // Insert selected extra options
        if (!empty($_POST['extra_options'])) {
            foreach ($_POST['extra_options'] as $option_id) {
                $stmt_opt = $conn->prepare("SELECT name FROM extra_options WHERE id = :option_id");
                $stmt_opt->bindParam(':option_id', $option_id);
                $stmt_opt->execute();
                $option = $stmt_opt->fetch(PDO::FETCH_ASSOC);

                if ($option) {
                    $stmt_insert_opt = $conn->prepare("INSERT INTO location_options (location_id, option_name) 
                                                       VALUES (:location_id, :option_name)");
                    $stmt_insert_opt->bindParam(':location_id', $location_id);
                    $stmt_insert_opt->bindParam(':option_name', $option['name']);
                    $stmt_insert_opt->execute();
                }
            }
        }

        // Set success message for add and redirect
        $_SESSION['success_message'] = "Location added successfully!";
        header("Location: locations.php"); // Redirect to locations page
        exit;
    } else {
        echo "Error: Could not save location.";
    }
}
?>
