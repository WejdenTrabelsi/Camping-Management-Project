<h2>Welcome Admin</h2>
<p>Your account has been activated.</p>
