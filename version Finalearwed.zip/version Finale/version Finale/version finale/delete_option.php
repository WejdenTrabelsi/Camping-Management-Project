<?php
session_start();
require_once 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Check if ID is provided
if (!isset($_GET['id'])) {
    header("Location: options.php");
    exit;
}

$option_id = $_GET['id'];

try {
    // Start a transaction
    $conn->beginTransaction();

    // Delete related entries in the location_options table
    $stmt = $conn->prepare("DELETE FROM location_options WHERE option_name IN (SELECT name FROM extra_options WHERE id = ?)");
    $stmt->execute([$option_id]);

    // Now, delete the option from the extra_options table
    $stmt = $conn->prepare("DELETE FROM extra_options WHERE id = ?");
    $stmt->execute([$option_id]);

    // Commit the transaction
    $conn->commit();

    // Redirect back to the options page with a success message
    header("Location: options.php?success=Option deleted successfully");
    exit;

} catch (PDOException $e) {
    // Rollback the transaction in case of an error
    $conn->rollBack();
    echo "Error: " . $e->getMessage();
}
?>
