<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Camping Adventures</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="home page yahya/assets/css/signup.css">
    <style>
        .toggle-container {
  display: flex;
  align-items: center;
  width: 120px;
  background-color: transparent;
  border:1px solid rgba(255, 255, 255, 0.5);
  border-radius: 25px;
  cursor: pointer;
  position: relative;
  transition: background 0.3s ease-in-out;
        }
        body {
  background: url('home%20page%20yahya/assets/img/signup-background.jpg') no-repeat;
  background-size: cover;
  background-position: center;
}


.toggle-button {
  width: 50%;
  text-align: center;
  padding: 10px;
  font-size: 18px;
  font-weight: bold;
  transition: all 0.3s ease-in-out;
  color:rgba(0, 0, 0, 0.84);
  
}


.active {
  color: white;
  font-weight: bold;
}

.female.active {
  background-color: rgba(249, 116, 213, 0.81);
  border-radius: 25px 0 0 25px;
}

.male.active {
  background-color: rgba(98, 211, 255, 0.81);;
  border-radius: 0 25px 25px 0;
}
.center-container {
display: flex;
justify-content: center; /* Centers horizontally */


}
    </style>
</head>
<body>
    <div class="form-container">
        <div class="form-logo">
            <img src="home page yahya/assets/img/logo.svg" alt="Camping Adventures">
        </div>
        <h1 class="form-title" style="font-size:31px;">Create Your Account</h1>
        
        <?php if (isset($_SESSION['signup_message'])): ?>
            <div class="message <?= strpos($_SESSION['signup_message'], 'success') ? 'success' : 'error' ?>">
                <?= $_SESSION['signup_message'] ?>
            </div>
            <?php unset($_SESSION['signup_message']); ?>
        <?php endif; ?>

        <form action="signup_process.php" method="POST" enctype="multipart/form-data">
            <div class="input-box">
                <input type="email" name="email" placeholder="Email Address" required>
                <i class='bx bxl-gmail' ></i>
            </div>    
            <div class="input-box">
                <input type="text" name="username" placeholder="Username" minlength="4" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="password" name="password" placeholder="Password" minlength="8" required>
                <i class='bx bxs-lock-alt' ></i>
            </div>
<!-- Gender Selection -->
<input type="hidden" name="gender" id="gender-input" value="female">
<div class="center-container">
<div class="toggle-container" onclick="toggleGender()">
    <div id="female" class="toggle-button female active">
        <i class='bx bx-female-sign' ></i>
    </div>
    <div id="male" class="toggle-button male">
        <i class='bx bx-male-sign'></i>
    </div>
</div>
</div>
<br>

<!-- Age Selection -->
<div class="age-box">
    <label for="age" style="display: flex;
    justify-content: center;">Age: <span id="ageValue">18</span></label>
    <input type="range" id="age" name="age" min="18" max="100" value="18" oninput="updateAge(this.value)" required>
</div>
<br>

<script>
    function updateAge(value) {
        document.getElementById("ageValue").textContent = value;
    }
</script>

            <div class="scroll-btn">
                <select name="role" required>
                    <option value="" disabled selected>Select Role</option>
                    <option value="client">Camper</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            

            <button type="submit">Sign Up</button>
        </form>
        
        <div class="login-link">
            Already have an account?<a href="index.php">Log In</a>
        </div>
    </div>
    <script src="home page yahya/assets/js/gsap.min.js"></script>

    <script>
        gsap.from('.form-logo',1.2, {opacity: 0, y:-50, delay: .3})
        gsap.from('.form-container',1.2, {opacity: 0, y:-50, delay: .1})
        gsap.from('.form-title',1.2, {opacity: 0, y:-50, delay: .5})
        gsap.from('.input-box',1.2, {opacity: 0, y:-50, delay: .7})
        gsap.from('.scroll-btn',1.2, {opacity: 0, y:-50, delay: 1})
        gsap.from('.file-label',1.2, {opacity: 0, y:-50, delay: 1.2})
        gsap.from('.file-name',1.2, {opacity: 0, y:-50, delay: 1.4})
        gsap.from('button',1.2, {opacity: 0, y:-50, delay: 1.6})
        gsap.from('.login-link',1.2, {opacity: 0, y:-50, delay: 1.8})
        gsap.from('.toggle-container',1.2, {opacity: 0, y:-50, delay: 1.6})
    </script>
     <script>
    function toggleGender() {
    let femaleBtn = document.getElementById("female");
    let maleBtn = document.getElementById("male");
    let genderInput = document.getElementById("gender-input");

    if (femaleBtn.classList.contains("active")) {
        // Switch to Male
        femaleBtn.classList.remove("active");
        maleBtn.classList.add("active");
        genderInput.value = "male"; // Update hidden input
    } else {
        // Switch to Female
        maleBtn.classList.remove("active");
        femaleBtn.classList.add("active");
        genderInput.value = "female"; // Update hidden input
    }
}
</script>

</body>
</html>