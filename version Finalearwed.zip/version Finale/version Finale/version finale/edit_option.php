<?php
session_start();
require_once 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Check if ID and form data are provided
if (!isset($_GET['id']) || !isset($_POST['name']) || !isset($_POST['description'])) {
    header("Location: options.php");
    exit;
}

$option_id = $_GET['id'];
$new_name = $_POST['name'];
$new_description = $_POST['description'];

try {
    // Start a transaction
    $conn->beginTransaction();

    // Update the option in the extra_options table
    $stmt = $conn->prepare("UPDATE extra_options SET name = ?, description = ? WHERE id = ?");
    $stmt->execute([$new_name, $new_description, $option_id]);

    // Now, we need to update the `location_options` table with the new `option_id`
    $stmt = $conn->prepare("UPDATE location_options SET option_id = (SELECT id FROM extra_options WHERE name = ?) WHERE option_id = ?");
    $stmt->execute([$new_name, $option_id]);

    // Commit the transaction
    $conn->commit();

    // Redirect to locations page after the update
    header("Location: locations.php?success=Option updated successfully");
    exit;

} catch (PDOException $e) {
    // Rollback the transaction in case of an error
    $conn->rollBack();
    echo "Error: " . $e->getMessage();
}
?>
