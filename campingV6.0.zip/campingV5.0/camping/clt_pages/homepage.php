<?php
session_start();
include('../db/db.php');

// Check if the user is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'client') {
    // User is not logged in
    $is_logged_in = false;
} else {
    // User is logged in
    $is_logged_in = true;
    $username = $_SESSION['username'];
    $user_id = $_SESSION['user_id'];
}


// Logout functionality
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();  // Remove all session variables
    session_destroy(); // Destroy the session
    header('Location: ../login/index.php'); // Redirect to login page
    exit();
}
if ($is_logged_in) {
$query = $conn->prepare("
    SELECT n.*
    FROM notifications n
    LEFT JOIN user_notifications un
        ON n.id = un.notification_id AND un.user_id = ?
    WHERE un.is_deleted IS NULL OR un.is_deleted = 0
    ORDER BY n.created_at DESC
");
$query->execute([$user_id]);
$notifications = $query->fetchAll(PDO::FETCH_ASSOC);

// Prepare the query to count the notifications
$query = $conn->prepare("
    SELECT COUNT(*) 
    FROM notifications n
    LEFT JOIN user_notifications un
        ON n.id = un.notification_id AND un.user_id = ?
    WHERE un.is_deleted IS NULL OR un.is_deleted = 0
");

// Execute the query
$query->execute([$user_id]);

// Fetch the count
$notificationCount = $query->fetchColumn();

if (isset($_GET['mark_read']) && isset($_GET['notification_id'])) {
    $notification_id = $_GET['notification_id'];
    
    $query = $conn->prepare("
        INSERT INTO user_notifications (user_id, notification_id, is_read, is_deleted)
        VALUES (?, ?, 1, 0)
        ON DUPLICATE KEY UPDATE is_read = 1
    ");
    $query->execute([$user_id, $notification_id]);
    header("Location: homepage.php");
    exit();
}
if (isset($_GET['delete']) && isset($_GET['notification_id'])) {
    $notification_id = $_GET['notification_id'];

    $query = $conn->prepare("
        INSERT INTO user_notifications (user_id, notification_id, is_read, is_deleted)
        VALUES (?, ?, 0, 1)
        ON DUPLICATE KEY UPDATE is_deleted = 1
    ");
    $query->execute([$user_id, $notification_id]);
    header("Location: homepage.php");
}
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--=============== FAVICON ===============-->
    <link rel="shortcut icon" href="../profile-icons/favicon.png" type="image/x-icon">

    <!--=============== REMIXICONS ===============-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.4.0/remixicon.css" crossorigin="">

    <!--=============== CSS ===============-->
    <link rel="stylesheet" href="../style/styles.css">
    

    <title>Responsive camping website</title>

    <!-- CSS for Dropdown -->
    <style>
        /* Profile Button (located at top-right corner) */
        .profile-dropdown-container {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .profile-button {
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px; /* Increase padding for a bigger button */
            border-radius: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transform: translateY(-10px); /* Push the button upward */
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        .profile-icon:hover{
    filter:brightness(1.5);
    box-shadow: 0 0 15px rgba(255, 255, 255, 0.8);
}

        /* Profile Dropdown Menu */
        .profile-dropdown {
            display: none; /* Hidden by default */
            position: absolute;
            top: 50px; /* Position below the button */
            right: 0;
            background-color: white;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            min-width: 200px;
            text-align: center;
            border:2px solid black;
        }

        .profile-dropdown p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .logout-btn {
            padding: 10px;
            background: linear-gradient(90deg, hsl(210, 55%, 20%), hsl(192, 62%, 25%)); /* Apply the gradient */
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
            font-weight:600;
            font-size:21px;
        }

        .logout-btn:hover {
            background: linear-gradient(90deg, hsl(210, 55%, 40%), hsl(192, 62%, 35%));
        }
        .nav__button-ghost{
  background: var(--gradient-color);
  margin-top: 6px;
  padding: .7rem 1rem;
  border-radius: 1.5rem;
  color:white;
}
.nav__button-ghost:hover {
            background: linear-gradient(90deg, hsl(210, 55%, 40%), hsl(192, 62%, 35%));
        }
        .home__button:hover{
  
  background: linear-gradient(90deg, hsl(210, 55%, 40%), hsl(192, 62%, 35%));;
}

        

.nav__button-link{ 
background: var(--gradient-color);
  margin-top: 6px;
  padding: .7rem 1rem; 
  border-radius: 1.5rem;
  color:white;}
  .nav__button-link:hover {
            background: linear-gradient(90deg, hsl(210, 55%, 40%), hsl(192, 62%, 35%));
        }


  .notification-container {
    position: fixed;
    top: 10px;
    right: 20px;
    cursor: pointer;
}

.notification-icon {
    width: 40px;
    height: 40px;
    display: inline-block; /* Ensures the icon is treated as inline element */
    position: relative;
    top:8px;
}
.notification-icon:hover {
    filter:brightness(1.2);
    transform: scale(1.5);
}

.badge {
    position: absolute; /* Position the badge absolutely within the notification container */
    top: 0; /* Position it at the top-right corner of the icon */
    right: 0; /* Position it at the top-right corner of the icon */
    background-color: #EC4550 ; /* Set a red background for the badge */
    color: white; /* Set the text color of the badge to white */
    font-size: 12px; /* Set the font size of the badge text */
    font-weight: bold; /* Make the badge text bold */
    border-radius: 50%; /* Make the badge circular */
    padding: 2px 6px; /* Add some padding around the text */
    min-width: 20px; /* Set a minimum width for the badge */
    height: 20px; /* Set a height for the badge */
    display: inline-flex;
    align-items: center; /* Vertically align the text in the center */
    justify-content: center; /* Horizontally align the text in the center */
    text-align: center; /* Make sure the text inside is centered */
    visibility: visible; /* Ensure the badge is visible */
}


.modal {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.modal-content {
    position: relative;
}

.close {
    position: absolute;
    top: 5px;
    right: 10px;
    font-size: 20px;
    cursor: pointer;
}
.edit-account-btn {
    display: block;
    margin-top: 10px;
    padding: 10px;
    background: linear-gradient(90deg, hsl(210, 55%, 20%), hsl(192, 62%, 25%));
    color: white;
    text-decoration: none;
    border-radius: 5px;
    margin-bottom:10px;
    font-weight:600;
}

.edit-account-btn:hover {
    background: linear-gradient(90deg, hsl(210, 55%, 40%), hsl(192, 62%, 35%));
}
/* Style for buttons */
.btn-read, .btn-delete {
    padding: 5px 10px;
    margin-left: 10px;
    text-decoration: none;
    color: white;
    border-radius: 5px;
}

.btn-read {
    background-color: #4CAF50; /* Green */
}

.btn-delete {
    background-color: #f44336; /* Red */
}

.btn-read:hover, .btn-delete:hover {
    opacity: 0.8;
}
/* Modal Overlay - Background */
.modal {
    display: none;  /* Hidden by default */
   
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5); /* Background overlay */
    padding-top: 60px;
    transition: all 0.3s ease;
}

/* Modal Content Box */
.modal-content {
    background-color: #fff;
    margin: 0 auto; /* Center the modal horizontally */
    padding: 20px;
    border-radius: 10px;
    width: 80%;  /* Adjust width */
    max-width: 600px; /* Maximum width */
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    position: relative;
    top: 50%; /* Position it vertically in the middle */
    transform: translateY(-50%); /* Move it back up by 50% of its height */
    max-height: 80vh; /* Set the maximum height of the modal */
    overflow-y: auto; /* Enable vertical scrolling if content exceeds max height */
}

/* Close Button (X) */
.close {
    color: #aaa;
    font-size: 28px;
    font-weight: bold;
    position: absolute;
    top: 10px;
    right: 15px;
    cursor: pointer;
    transition: color 0.3s ease;
}

.close:hover,
.close:focus {
    color: #333;
}

/* Title */
.modal-content h2 {
    margin-top: 0;
    font-size: 24px;
    color: #333;
    text-align: center;
}

/* Notification List */
#notification-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

#notification-list li {
    padding: 15px;
    background-color: #f9f9f9;
    border-bottom: 1px solid #ddd;
    border-radius: 8px;
    margin-bottom: 10px;
    transition: background-color 0.3s ease;
}

#notification-list li:hover {
    background-color: #f1f1f1;
}

#notification-list li small {
    display: block;
    margin-top: 5px;
    color: #888;
    font-size: 12px;
}

/* Buttons (Mark as Read & Delete) */
.btn-read, .btn-delete {
    padding: 8px 16px;
    border-radius: 5px;
    text-decoration: none;
    color: white;
    margin-top: 10px;
    display: inline-block;
    transition: background-color 0.3s ease;
}

.btn-read {
    background-color: #4CAF50; /* Green */
}

.btn-read:hover {
    background-color: #45a049;
}

.btn-delete {
    background-color: #f44336; /* Red */
}

.btn-delete:hover {
    background-color: #e53935;
}

/* Button Container */
button-container {
    margin-top: 10px;
}



    </style>
</head>
<body>

    <!--==================== HEADER ====================-->
    <header class="header" id="header">
        <nav class="nav container">
            <a href="#" class="nav__logo">
                <img src="../profile-icons/logo.svg" alt="logo">
            </a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item">
                        <a href="#" class="nav__link"s>Home</a>
                    </li>
                
                    <li class="nav__item">
                        <a href="location.php" class="nav__link">locations</a>
                    </li>  
                    <li class="nav__item">
                        <a href="contact us/contactus.php" class="nav__link">Contact us</a>
                    </li>           
                </ul>

                <?php if (!$is_logged_in): ?>
                    <div class="nav__buttons">
                        <a href="../login/index.php" class="nav__button-link">Login</a>
                        <a href="sign up/signup_choice.php" class="nav__button-ghost">Get Started</a>
                    </div>
                <?php else: ?>
                    <!-- Profile Dropdown Button -->
                    <div class="profile-dropdown-container">
                        <button class="profile-button" id="profile-button">
                            <img src="../profile-icons\client-icon.png" alt="Profile Icon" class="profile-icon">
                        </button>
                        
                        <!-- Dropdown Menu -->
                        <div class="profile-dropdown" id="profile-dropdown">
                            <p id="username-display"><?php echo $_SESSION['username']; ?></p>
                            <a href="edit-client-account.php" class="edit-account-btn">Edit Account</a>

                            <form action="../logout/logout.php" method="post">
                                <button type="submit" name="logout" class="logout-btn">Logout</button>
                            </form>
                        </div>
                    </div>
                                    <!-- Notification container: This is the icon that the user clicks to view notifications -->
                                    <div class="notification-container" onclick="toggleNotifications()">
                                        <!-- Replace the SVG bell icon with an image -->
                                        <img src="../profile-icons/notif-icon.png" alt="Notification Icon" class="notification-icon" width="40" height="40">
                                        <!-- Notification badge showing the number of unread notifications -->
                                        <?php if ($notificationCount > 0): ?>
                                            <span id="notification-count" class="badge"><?= $notificationCount ?></span>
                                        <?php else: ?>
                                            <span id="notification-count" class="badge" style="display:none;"></span> <!-- Hide if no notifications -->
                                        <?php endif; ?>
                                    </div>

                    

<!-- Modal that displays the notifications when clicked -->
<div id="notification-modal" class="modal">
    <div class="modal-content">
        <!-- Close button to hide the modal -->
        <span class="close" onclick="toggleNotifications()">&times;</span>
        <h2>Notifications</h2>
        <!-- List to display the notifications dynamically -->
        <ul id="notification-list">
    <?php foreach ($notifications as $index => $notification): ?>
        <li id="notification-<?= $notification['id'] ?>" class="notification-item">
            <?= htmlspecialchars($notification['message']) ?> - 
            <small><?= $notification['created_at'] ?></small>
          
            <!-- Delete Button -->
            <a href="?delete=true&notification_id=<?= $notification['id'] ?>" class="btn-delete">Delete</a>
        </li>
        <?php if ($index < count($notifications) - 1): ?>
            <hr/>
        <?php endif; ?>
    <?php endforeach; ?>
</ul>


    </div>
</div>

                <?php endif; ?>
                
                
            </div>
            
        </nav>
    </header>
    <script>
        // Listen for when the tab is closed to destroy the session

        // Toggle the dropdown menu visibility when the profile button is clicked
        document.getElementById("profile-button").addEventListener("click", function(event) {
            const dropdown = document.getElementById("profile-dropdown");
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
            event.stopPropagation(); // Prevent the event from bubbling up
        });

        // Close the dropdown menu if clicking outside
        document.addEventListener("click", function(event) {
            const dropdown = document.getElementById("profile-dropdown");
            const profileButton = document.getElementById("profile-button");
            if (!profileButton.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = "none";
            }
        });
         // Add confirmation for logout
    document.querySelector('.logout-btn').addEventListener('click', function(event) {
        // Show confirmation dialog
        const confirmed = confirm("Are you sure you want to log out?");
        
        // If user clicks 'Cancel', prevent the form from submitting
        if (!confirmed) {
            event.preventDefault(); // Prevent the logout form submission
        }
    });
    </script>

    <!--==================== MAIN ====================-->
    <main class="main">
        <!--==================== HOME ====================-->
        <section class="home">
            <div class="home__container container">
                <div class="home__content">
                    <div class="home__data">
                        <h3 class="home__subtitle">A LIFETIME EXPERIENCE</h3>
                        <h1 class="home__title">
                            Camping Events <br>
                            To Remember
                        </h1>
                        <p class="home__description">Camp anywhere anytime without hassle and enjoy.</p>
                        <a href="location.php" class="home__button">Explore Locations</a>
                    </div>
                    <img src="../profile-icons/bird-1.svg" alt="image" class="home__bird-1">
                    <img src="../profile-icons/bird-2.svg" alt="image" class="home__bird-2">
                </div>
                <div class="home__images">
                    <img src="../profile-icons/img-4.svg" alt="image" class="home__img-4">
                    <img src="../profile-icons/img-3.svg" alt="image" class="home__img-3">
                    <img src="../profile-icons/img-2.svg" alt="image" class="home__img-2">
                    <img src="../profile-icons/img-1.svg" alt="image" class="home__img-1">
                </div>
            </div>
        </section>
    </main>
    
    <!--=============== GSAP ===============-->
    <script src="../js/gsap.min.js"></script>

    <!--=============== MAIN JS ===============-->
    <script src="../js/main.js"></script>

<script>// Function to fetch notifications from the server


// Function to toggle the visibility of the notification modal
function toggleNotifications() {
    const modal = document.getElementById('notification-modal');
    // Toggle the modal visibility between "block" and "none"
    modal.style.display = modal.style.display === "block" ? "none" : "block";

    
}
function markAsRead(notificationId) {
    // Make a POST request to mark the notification as read
    fetch('mark_as_read.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `notification_id=${notificationId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Hide the "Mark as Read" button and show the "Read" label
            document.getElementById(`btn-read-${notificationId}`).style.display = 'none';
            document.getElementById(`read-label-${notificationId}`).style.display = 'inline';
        } else {
            console.error('Failed to mark notification as read');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}




// Automatically fetch notifications when the page loads
window.onload = fetchNotifications;
</script>
<script
  src="https://unpkg.com/@dotlottie/player-component@2.7.12/dist/dotlottie-player.mjs"
  type="module"
></script>




</body>
</html>
