<?php
session_start();
include('../db/db.php');

$username = $_POST['username'];
$password = $_POST['password'];

$query = $conn->prepare("SELECT * FROM users WHERE username = ?");
$query->execute([$username]);
$user = $query->fetch();

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['user_id'] = $user['id'];

    if ($user['role'] == 'admin') {
        if ($user['status'] == 'pending') {
            $_SESSION['login_message'] = "⏳ Your admin account is pending approval. Please wait for the superadmin.";
            header("Location: index.php");
            exit();
        } elseif ($user['status'] == 'deactivated') {
            $_SESSION['login_message'] = "🚫 Your admin account has been deactivated.";
            header("Location: index.php");
            exit();
        } elseif ($user['status'] == 'active') {
            header("Location: ../admin/admin_dashboard.php");
            exit();
        }
    } elseif ($user['role'] == 'client') {
        if ($user['status'] == 'pending') {
            $_SESSION['login_message'] = "⏳ Your client account is pending approval. Please wait for an admin.";
            header("Location: index.php");
            exit();
        } elseif ($user['status'] == 'deactivated') {
            $_SESSION['login_message'] = "🚫 Your client account has been deactivated.";
            header("Location: index.php");
            exit();
        } elseif ($user['status'] == 'active') {
            header("Location: ../clt_pages/homepage.php");
            exit();
        }
    }
} elseif ($username === 'superadmin' && $password === 'superadmin') {
    $_SESSION['username'] = "superadmin";
    $_SESSION['role'] = "superadmin";
    header("Location: ../superadmin/superadmin_dashboard.php");
    exit();
} else {
    $_SESSION['login_message'] = "❌ Invalid username or password.";
    header("Location: index.php");
    exit();
}
?>
