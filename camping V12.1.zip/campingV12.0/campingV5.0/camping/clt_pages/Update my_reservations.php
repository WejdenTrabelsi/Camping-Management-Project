<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Show success message if redirected from successful reservation
if (isset($_SESSION['reservation_success'])) {
    echo '<div class="alert alert-success">Reservation created successfully!</div>';
    unset($_SESSION['reservation_success']);
}

// Get user's reservations
$stmt = $conn->prepare("
    SELECT r.*, l.name as location_name 
    FROM reservations r
    JOIN locations l ON r.location_id = l.id
    WHERE r.user_id = ?
    ORDER BY r.start_date DESC
");
$stmt->execute([$_SESSION['user_id']]);
$reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Your HTML to display reservations -->