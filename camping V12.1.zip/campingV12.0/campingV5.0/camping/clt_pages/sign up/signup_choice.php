<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Camping Adventures</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../../style/signup.css">
    <style>
        .toggle-container {
            display: flex;
            align-items: center;
            width: 120px;
            background-color: transparent;
            border:1px solid rgba(255, 255, 255, 0.5);
            border-radius: 25px;
            cursor: pointer;
            position: relative;
            transition: background 0.3s ease-in-out;
        }

        body {
            background: url('../../profile-icons/signup-background.jpg') no-repeat;
            background-size: cover;
            background-position: center;
        }

        .toggle-button {
            width: 50%;
            text-align: center;
            padding: 10px;
            font-size: 18px;
            font-weight: bold;
            transition: all 0.3s ease-in-out;
            color: rgba(0, 0, 0, 0.84);
        }

        .active {
            color: white;
            font-weight: bold;
        }

        .female.active {
            background-color: rgba(249, 116, 213, 0.81);
            border-radius: 25px 0 0 25px;
        }

        .male.active {
            background-color: rgba(98, 211, 255, 0.81);
            border-radius: 0 25px 25px 0;
        }

        .center-container {
            display: flex;
            justify-content: center;
        }
        .form-container {
            width: 400px;
            height: 400px;
            padding-top: 80px;
            text-align: center;
            transition: transform 0.3s ease;
         }
        .form-container:hover{
            transform: translateY(-20px) !important;
            background: rgba(255, 255, 255, 0.39);
            color: #00264E;
        }
        .form-container:hover img{
            filter:invert(0) !important;
        }
        a.clickable-container {
        text-decoration: none; /* Removes underline from the link */
        display: inline-block; /* Ensures the anchor behaves like a block element */
        }

        a.clickable-container h2 {
        text-decoration: none; /* Ensures the <h2> inside the link doesn't get underlined */
        }

        
    </style>
</head>
<body>
    <div style="display: flex; gap: 30px;">
        <a href="admin-signup.php" class="clickable-container">
            <div class="form-container">
                <img src="../../profile-icons/admin-image.png" alt="Camping Adventures" width=170px style="filter:invert(1);">
                <h2> sign up as admin </h2>
            </div>
        </a>
        <a href="client-signup.php" class="clickable-container">
            <div class="form-container"style="width: 400px; height: 400px;">
                <img src="../../profile-icons/client-image.png" alt="Camping Adventures" width=170px style="filter:invert(1);">
                <h2> sign up as client </h2>
            </div>
        </a>
    </div>
    <script src="../../js/gsap.min.js"></script>

    <script>
        gsap.from('.form-container',1.2, {opacity: 0, y:-5, delay: .3});
        gsap.from('img',1.2, {opacity: 0, y:-100, delay: .1});
        gsap.from('h2',1.2, {opacity: 0, y:-50, delay: .5});
 
    </script>

    =
</body>
</html>
