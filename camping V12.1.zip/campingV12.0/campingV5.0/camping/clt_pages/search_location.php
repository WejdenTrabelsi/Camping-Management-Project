<?php
require_once '../db/db.php';

header('Content-Type: application/json');

if (!isset($_GET['query']) || strlen($_GET['query']) < 2) {
    echo json_encode([]);
    exit;
}

$query = $conn->prepare("
    SELECT id, name, type, description 
    FROM locations 
    WHERE name LIKE :query OR description LIKE :query
    ORDER BY name
    LIMIT 10
");

$searchTerm = '%' . $_GET['query'] . '%';
$query->bindParam(':query', $searchTerm);
$query->execute();

$results = $query->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($results);