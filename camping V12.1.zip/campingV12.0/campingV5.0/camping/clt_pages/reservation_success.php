<?php
require_once '../db/db.php';

$reservation_id = $_GET['id'] ?? 0;

// Get reservation details
$stmt = $conn->prepare("SELECT r.*, l.name as location_name 
                       FROM reservations r
                       JOIN locations l ON r.location_id = l.id
                       WHERE r.id = ?");
$stmt->execute([$reservation_id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reservation) {
    header("Location: locations.php");
    exit;
}

// Get services
$stmt = $conn->prepare("SELECT eo.name, eo.price 
                       FROM reservation_services rs
                       JOIN extra_options eo ON rs.service_id = eo.id
                       WHERE rs.reservation_id = ?");
$stmt->execute([$reservation_id]);
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation Confirmed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .confirmation-card {
            max-width: 600px;
            margin: 50px auto;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card confirmation-card">
        <div class="card-header bg-success text-white">
            <h4 class="mb-0">Reservation Confirmed</h4>
        </div>
        <div class="card-body">
            <h5 class="card-title">Thank you for your reservation!</h5>
            <p class="card-text">Your reservation details are below:</p>
            
            <div class="mb-3">
                <h6>Reservation #<?= $reservation['id'] ?></h6>
                <p><strong>Location:</strong> <?= htmlspecialchars($reservation['location_name']) ?></p>
                <p><strong>Dates:</strong> <?= date('M j, Y', strtotime($reservation['start_date'])) ?> to <?= date('M j, Y', strtotime($reservation['end_date'])) ?></p>
                <p><strong>Total Price:</strong> $<?= number_format($reservation['total_price'], 2) ?></p>
                <p><strong>Payment Method:</strong> <?= ucwords(str_replace('_', ' ', $reservation['payment_method'])) ?></p>
                
                <?php if (!empty($services)): ?>
                    <h6>Additional Services:</h6>
                    <ul>
                        <?php foreach ($services as $service): ?>
                            <li><?= htmlspecialchars($service['name']) ?> ($<?= number_format($service['price'], 2) ?>)</li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
            
            <a href="../clt_pages/locations.php" class="btn btn-primary">Back to Locations</a>
            <a href="../clt_pages/my_reservations.php" class="btn btn-secondary">View My Reservations</a>
        </div>
    </div>
</div>
</body>
</html>