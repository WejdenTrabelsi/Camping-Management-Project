<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
session_start();
require_once '../db/db.php';
require_once 'PHPMailer/PHPMailer-master/src/Exception.php';
require_once 'PHPMailer/PHPMailer-master/src/PHPMailer.php';
require_once 'PHPMailer/PHPMailer-master/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

if (isset($_GET['id']) && isset($_GET['action'])) {
    $reservation_id = $_GET['id'];
    $action = $_GET['action'];
    
    try {
        // Get reservation details with client email
        $stmt = $conn->prepare("
            SELECT r.*, u.email, u.username, l.name as location_name 
            FROM reservations r
            JOIN users u ON r.user_id = u.id
            JOIN locations l ON r.location_id = l.id
            WHERE r.id = ?
        ");
        $stmt->execute([$reservation_id]);
        $reservation = $stmt->fetch();
        
        if (!$reservation) {
            $_SESSION['error'] = "Reservation not found";
            header("Location: client-reservations.php");
            exit;
        }
        
        // Update based on action
        switch ($action) {
            case 'confirm':
                if ($reservation['status'] == 'pending') {
                    $stmt = $conn->prepare("UPDATE reservations SET status = 'confirmed' WHERE id = ?");
                    $stmt->execute([$reservation_id]);
                    $_SESSION['success'] = "Reservation confirmed successfully";
                    
                    // Send confirmation email
                    sendConfirmationEmail($reservation);
                }
                break;
                
            case 'cancel':
                $stmt = $conn->prepare("UPDATE reservations SET status = 'cancelled' WHERE id = ?");
                $stmt->execute([$reservation_id]);
                $_SESSION['success'] = "Reservation cancelled successfully";
                break;
                
            default:
                $_SESSION['error'] = "Invalid action";
                break;
        }
        
    } catch (PDOException $e) {
        $_SESSION['error'] = "Database error: " . $e->getMessage();
    }
}

header("Location: client-reservations.php");
exit;

function sendConfirmationEmail($reservation) {
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'trabelsiwejden911@gmail.com';
        $mail->Password   = 'iwsi iacf hjct jgph';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        // Recipients
        $mail->setFrom('trabelsiwejden911@gmail.com', 'Camping Management');
        $mail->addAddress($reservation['email'], $reservation['username']);

        // Format dates
        $startDate = date('F j, Y', strtotime($reservation['start_date']));
        $endDate = date('F j, Y', strtotime($reservation['end_date']));

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Your Reservation #'.$reservation['id'].' is Confirmed';
        
        // HTML body with reservation details
        $mail->Body = '
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background-color: #425C97; color: white; padding: 10px; text-align: center; }
                    .content { padding: 20px; }
                    .details { margin: 20px 0; }
                    .footer { margin-top: 20px; font-size: 0.9em; color: #666; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h2>Reservation Confirmation</h2>
                    </div>
                    <div class="content">
                        <p>Dear '.$reservation['username'].',</p>
                        <p>Your reservation has been confirmed. Here are the details:</p>
                        
                        <div class="details">
                            <h3>Reservation #'.$reservation['id'].'</h3>
                            <p><strong>Location:</strong> '.$reservation['location_name'].'</p>
                            <p><strong>Dates:</strong> '.$startDate.' to '.$endDate.'</p>
                            <p><strong>Total Price:</strong> $'.number_format($reservation['total_price'], 2).'</p>
                            <p><strong>Status:</strong> Confirmed</p>
                        </div>
                        
                        <p>Thank you for choosing our camping service. If you have any questions, please don\'t hesitate to contact us.</p>
                        
                        <div class="footer">
                            <p>Best regards,<br>Camping Management Team</p>
                        </div>
                    </div>
                </div>
            </body>
            </html>
        ';
        
        // Plain text version for non-HTML email clients
        $mail->AltBody = "Reservation Confirmation\n\n" .
            "Dear ".$reservation['username'].",\n\n" .
            "Your reservation has been confirmed. Here are the details:\n\n" .
            "Reservation #".$reservation['id']."\n" .
            "Location: ".$reservation['location_name']."\n" .
            "Dates: ".$startDate." to ".$endDate."\n" .
            "Total Price: $".number_format($reservation['total_price'], 2)."\n" .
            "Status: Confirmed\n\n" .
            "Thank you for choosing our camping service.\n\n" .
            "Best regards,\nCamping Management Team";

        $mail->send();
        error_log("Confirmation email sent to ".$reservation['email']);
        
    } catch (Exception $e) {
        error_log("Email error: ".$e->getMessage());
        // You might want to handle this error differently in production
        $_SESSION['error'] = "Reservation confirmed but email failed to send: " . $e->getMessage();
    }
}
