<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login/index.php");
    exit;
}

$reservation_id = $_GET['id'] ?? 0;

// Fetch reservation details
$stmt = $conn->prepare("
    SELECT r.*, u.username as client_name, u.email as client_email, 
           l.name as location_name, l.price as location_price
    FROM reservations r
    JOIN users u ON r.user_id = u.id
    JOIN locations l ON r.location_id = l.id
    WHERE r.id = ?
");
$stmt->execute([$reservation_id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reservation) {
    $_SESSION['error'] = "Reservation not found";
    header("Location: admin_dashboard.php");
    exit;
}

// Fetch reservation services
$stmt = $conn->prepare("
    SELECT eo.name, eo.price 
    FROM reservation_services rs
    JOIN extra_options eo ON rs.service_id = eo.id
    WHERE rs.reservation_id = ?
");
$stmt->execute([$reservation_id]);
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate number of days
$start = new DateTime($reservation['start_date']);
$end = new DateTime($reservation['end_date']);
$days = $start->diff($end)->days;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .view-container {
            max-width: 800px;
            margin: 50px auto;
        }
        .reservation-details {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="container view-container">
    <div class="card shadow">
        <div class="card-header bg-info text-white">
            <h4>Reservation Details #<?= $reservation['id'] ?></h4>
        </div>
        <div class="card-body reservation-details">
            <div class="row mb-3">
                <div class="col-md-6">
                    <h5>Client Information</h5>
                    <p><strong>Name:</strong> <?= htmlspecialchars($reservation['client_name']) ?></p>
                    <p><strong>Email:</strong> <?= htmlspecialchars($reservation['client_email']) ?></p>
                </div>
                <div class="col-md-6">
                    <h5>Reservation Status</h5>
                    <span class="badge bg-<?= $reservation['status'] === 'confirmed' ? 'success' : ($reservation['status'] === 'cancelled' ? 'danger' : 'warning') ?>">
                        <?= ucfirst($reservation['status']) ?>
                    </span>
                    <p><strong>Created:</strong> <?= date('M j, Y H:i', strtotime($reservation['created_at'])) ?></p>
                </div>
            </div>
            
            <hr>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <h5>Location Information</h5>
                    <p><strong>Location:</strong> <?= htmlspecialchars($reservation['location_name']) ?></p>
                    <p><strong>Base Price:</strong> $<?= number_format($reservation['location_price'], 2) ?> per day</p>
                    
                    
                </div>
                <div class="col-md-6">
                    <h5>Dates</h5>
                    <p><strong>From:</strong> <?= date('M j, Y', strtotime($reservation['start_date'])) ?></p>
                    <p><strong>To:</strong> <?= date('M j, Y', strtotime($reservation['end_date'])) ?></p>
                    <p><strong>Duration:</strong> <?= $days ?> days</p>
                    
                </div>
            </div>
            
            <hr>
            
            <div class="row mb-3">
            <div class="col-md-6">
                <h5>Additional Services</h5>
                <?php if (!empty($services)): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Service</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($services as $service): ?>
                                <tr>
                                    <td><?= htmlspecialchars($service['name']) ?></td>
                                    <td>$<?= number_format($service['price'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No additional services selected</p>
                <?php endif; ?>
                </div>
                <div class="col-md-6">
                <h5>participants</h5>
                    <p><strong>adults:</strong> <?= (int) $reservation['adults'] ?></p>
                    <p><strong>kids:</strong> <?= (int) $reservation['kids'] ?></p>
                </div>
            </div>
            
            <hr>
            
            <div class="mb-3">
                <h5>Payment Information</h5>
                <p><strong>Total Price:</strong> $<?= number_format($reservation['total_price'], 2) ?></p>
                <p><strong>Payment Method:</strong> <?= ucwords(str_replace('_', ' ', $reservation['payment_method'])) ?></p>
            </div>
            
            <div class="d-flex justify-content-between">
                <a href="client-reservations.php" class="btn btn-secondary">Back to reservations</a>
                <div>
                    <a href="edit_reservation.php?id=<?= $reservation['id'] ?>" class="btn btn-primary">Edit</a>
                    <?php if ($reservation['status'] != 'cancelled'): ?>
                        <a href="manage_reservation.php?action=cancel&id=<?= $reservation['id'] ?>" class="btn btn-danger">Cancel</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>