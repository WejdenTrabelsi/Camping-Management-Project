<?php
$selected = $_POST['selected_city'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Select a Governorate - Tunisia Map</title>
    <style>
        svg {
            width: 600px;
            height: auto;
        }
        path {
            fill: #ddd;
            stroke: #444;
            stroke-width: 1;
            cursor: pointer;
            transition: 0.2s;
        }
        path:hover {
            fill: #aaf;
        }
        path.active {
            fill: #00aaff;
        }

        #tooltip {
            position: absolute;
            background: white;
            padding: 5px 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.2);
            font-size: 14px;
            pointer-events: none;
            display: none;
            z-index: 1000;
        }
    </style>
</head>
<body>

<h2>Choose the Governorate You Are Responsible For</h2>

<?php if ($selected): ?>
    <p><strong>You selected:</strong> <?= htmlspecialchars($selected) ?></p>
<?php endif; ?>

<form method="post">
    <input type="hidden" name="selected_city" id="selected_city">

    <!-- Include the SVG map -->
    <?php include("tn.svg"); ?>

    <button type="submit">Confirm Selection</button>
</form>

<div id="tooltip"></div>

<script>
    const paths = document.querySelectorAll("svg path");
    const input = document.getElementById("selected_city");
    const tooltip = document.getElementById("tooltip");

    // Mapping of IDs to governorate names
    const governorates = {
        "TN11": "Tunis",
        "TN12": "Ariana",
        "TN13": "Ben Arous",
        "TN14": "Manubah",
        "TN21": "Nabeul",
        "TN22": "Zaghouan",
        "TN23": "Bizerte",
        "TN31": "Béja",
        "TN32": "Jendouba",
        "TN33": "Le Kef",
        "TN34": "Siliana",
        "TN41": "Kairouan",
        "TN42": "Kassérine",
        "TN43": "Sidi Bou Zid",
        "TN51": "Sousse",
        "TN52": "Monastir",
        "TN53": "Mahdia",
        "TN61": "Sfax",
        "TN71": "Gafsa",
        "TN72": "Tozeur",
        "TN73": "Kebili",
        "TN81": "Gabès",
        "TN82": "Médenine",
        "TN83": "Tataouine"
    };

    paths.forEach(path => {
        // Hover show
        path.addEventListener("mouseover", e => {
            const id = path.id; // Get the id of the path
            const name = governorates[id]; // Get the name from the mapping
            if (name) {
                tooltip.textContent = name; // Display the name if it's available
                tooltip.style.display = "block";
            }
        });

        // Hover move
        path.addEventListener("mousemove", e => {
            tooltip.style.left = e.pageX + 15 + "px";
            tooltip.style.top = e.pageY + 15 + "px";
        });

        // Hover out
        path.addEventListener("mouseout", () => {
            tooltip.style.display = "none";
        });

        // Click to select
        path.addEventListener("click", () => {
            paths.forEach(p => p.classList.remove("active"));
            path.classList.add("active");
            input.value = path.id;
        });
    });
</script>

</body>
</html>
