<?php
session_start();
require_once '../db/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        // Basic reservation data
        $user_id = $_POST['user_id'];
        $location_id = $_POST['location_id'];
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        $payment_method = $_POST['payment_method'];
        
        // Calculate total price
        $total_price = 0;
        
        // Get location price
        $stmt = $conn->prepare("SELECT price FROM locations WHERE id = ?");
        $stmt->execute([$location_id]);
        $location = $stmt->fetch(PDO::FETCH_ASSOC);
        $total_price = $location['price'];
        
        // Add services prices
        $services = $_POST['services'] ?? [];
        foreach ($services as $service) {
            $service_data = json_decode($service, true);
            $total_price += $service_data['price'];
        }
        
        // Calculate number of days
        $start = new DateTime($start_date);
        $end = new DateTime($end_date);
        $days = $start->diff($end)->days;
        $total_price *= $days;
        
        // Insert reservation
        $stmt = $conn->prepare("INSERT INTO reservations (user_id, location_id, start_date, end_date, total_price, payment_method) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $location_id, $start_date, $end_date, $total_price, $payment_method]);
        $reservation_id = $conn->lastInsertId();
        
        // Insert reservation services
        foreach ($services as $service) {
            $service_data = json_decode($service, true);
            $stmt = $conn->prepare("INSERT INTO reservation_services (reservation_id, service_id) VALUES (?, ?)");
            $stmt->execute([$reservation_id, $service_data['id']]);
        }
        
        $conn->commit();
        
        // Redirect to success page
        header("Location: reservation_success.php?id=$reservation_id");
        exit;
    } catch (PDOException $e) {
        $conn->rollBack();
        // Log error and redirect to error page
        error_log("Reservation error: " . $e->getMessage());
        header("Location: reservation_error.php");
        exit;
    }
} else {
    header("Location: reserve.php");
    exit;
}
?>