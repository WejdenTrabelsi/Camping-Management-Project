<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login/index.php");
    exit;
}

// Check if ID is provided
if (!isset($_GET['id'])) {
    header("Location: locations.php");
    exit;
}

// Get the location ID to delete
$location_id = $_GET['id'];

// First, delete the related entries from the location_options table
$stmt = $conn->prepare("DELETE FROM location_options WHERE location_id = :location_id");
$stmt->bindParam(':location_id', $location_id);
$stmt->execute();

// Now, get the location to delete the image
$stmt = $conn->prepare("SELECT image_path FROM locations WHERE id = :location_id");
$stmt->bindParam(':location_id', $location_id);
$stmt->execute();
$location = $stmt->fetch(PDO::FETCH_ASSOC);

// Delete the location
$stmt = $conn->prepare("DELETE FROM locations WHERE id = :location_id");
$stmt->bindParam(':location_id', $location_id);
$stmt->execute();

// Delete the image if it exists
if ($location && $location['image_path'] && file_exists($location['image_path'])) {
    unlink($location['image_path']);
}

header("Location: locations.php?success=Location deleted successfully");
exit;
?>
