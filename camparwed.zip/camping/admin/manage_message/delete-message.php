<?php
include 'db.php';
$id = $_GET['id'];
$conn->query("DELETE FROM client_messages WHERE id=$id");
header("Location: admin-messages.php");
?>
