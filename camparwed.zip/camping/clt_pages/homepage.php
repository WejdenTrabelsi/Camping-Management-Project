<?php


session_start();
include('../db/db.php');

// Check if the user is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'client') {
    // User is not logged in
    $is_logged_in = false;
} else {
    // User is logged in
    $is_logged_in = true;
    $username = $_SESSION['username'];
}
$user_id = $_SESSION['user_id'];

// Logout functionality
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();  // Remove all session variables
    session_destroy(); // Destroy the session
    header('Location: ../login/index.php'); // Redirect to login page
    exit();
}
$query = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC");
$notifications = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--=============== FAVICON ===============-->
    <link rel="shortcut icon" href="../profile-icons/favicon.png" type="image/x-icon">

    <!--=============== REMIXICONS ===============-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.4.0/remixicon.css" crossorigin="">

    <!--=============== CSS ===============-->
    <link rel="stylesheet" href="../style/styles.css">
    

    <title>Responsive camping website</title>

    <!-- CSS for Dropdown -->
    <style>
        /* Profile Button (located at top-right corner) */
        .profile-dropdown-container {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .profile-button {
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px; /* Increase padding for a bigger button */
            border-radius: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transform: translateY(-10px); /* Push the button upward */
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        .profile-icon:hover{
    filter:brightness(1.5);
    box-shadow: 0 0 15px rgba(255, 255, 255, 0.8);
}

        /* Profile Dropdown Menu */
        .profile-dropdown {
            display: none; /* Hidden by default */
            position: absolute;
            top: 50px; /* Position below the button */
            right: 0;
            background-color: white;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            min-width: 200px;
            text-align: center;
            border:2px solid black;
        }

        .profile-dropdown p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .logout-btn {
            padding: 10px;
            background: linear-gradient(90deg, hsl(210, 55%, 20%), hsl(192, 62%, 25%)); /* Apply the gradient */
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
        }

        .logout-btn:hover {
            background: linear-gradient(90deg, hsl(210, 55%, 40%), hsl(192, 62%, 35%));
        }
        .nav__button-ghost{
  background: var(--gradient-color);
  margin-top: 6px;
  padding: .7rem 1rem;
  border-radius: 1.5rem;
  color:white;
}

.nav__button-link{ 
background: var(--gradient-color);
  margin-top: 6px;
  padding: .7rem 1rem; 
  border-radius: 1.5rem;
  color:white;}
  .notification-container {
    position: fixed;
    top: 10px;
    right: 20px;
    cursor: pointer;
}

.notification-icon {
    width: 40px;
    height: 40px;
}

.badge {
    position: absolute;
    top: 0;
    right: 0;
    background: red;
    color: white;
    border-radius: 50%;
    padding: 5px 10px;
    font-size: 12px;
    display: none;
}


.modal {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.modal-content {
    position: relative;
}

.close {
    position: absolute;
    top: 5px;
    right: 10px;
    font-size: 20px;
    cursor: pointer;
}

    </style>
</head>
<body>

    <!--==================== HEADER ====================-->
    <header class="header" id="header">
        <nav class="nav container">
            <a href="#" class="nav__logo">
                <img src="../profile-icons/logo.svg" alt="logo">
            </a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item">
                        <a href="#" class="nav__link">Home</a>
                    </li>
                
                    <li class="nav__item">
                        <a href="location.php" class="nav__link">locations</a>
                    </li>  
                    <li class="nav__item">
                        <a href="contact us/contactus.php" class="nav__link">Contact us</a>
                    </li>           
                </ul>

                <?php if (!$is_logged_in): ?>
                    <div class="nav__buttons">
                        <a href="../login/index.php" class="nav__button-link">Login</a>
                        <a href="sign up/signup.php" class="nav__button-ghost">Get Started</a>
                    </div>
                <?php else: ?>
                    <!-- Profile Dropdown Button -->
                    <div class="profile-dropdown-container">
                        <button class="profile-button" id="profile-button">
                            <img src="../profile-icons\client-icon.png" alt="Profile Icon" class="profile-icon">
                        </button>
                        
                        <!-- Dropdown Menu -->
                        <div class="profile-dropdown" id="profile-dropdown">
                            <p id="username-display"><?php echo $_SESSION['username']; ?></p>
                            <form action="../logout/logout.php" method="post">
                                <button type="submit" name="logout" class="logout-btn">Logout</button>
                            </form>
                        </div>
                    </div>
                                    <!-- Notification container: This is the icon that the user clicks to view notifications -->
                    <div class="notification-container" onclick="toggleNotifications()">
                        <!-- SVG bell icon representing the notification icon -->
                        <svg class="notification-icon" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                        </svg>
                        <!-- The red badge showing the number of unread notifications -->
                        <span id="notification-count" class="badge"></span>
                    </div>
                    

                    <!-- Modal that displays the notifications when clicked -->
                    <div id="notification-modal" class="modal">
                        <div class="modal-content">
                            <!-- Close button to hide the modal -->
                            <span class="close" onclick="toggleNotifications()">&times;</span>
                            <h2>Notifications</h2>
                            <!-- List to display the notifications dynamically -->
                            <ul id="notification-list">
                            <?php foreach ($notifications as $index => $notification): ?>
                                <li><?= htmlspecialchars($notification['message']) ?> - <small><?= $notification['created_at'] ?></small></li>
                                <?php if ($index < count($notifications) - 1): ?>
                                    <hr/>
                                <?php endif; ?>
                            <?php endforeach; ?>

                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
                
                
            </div>
            
        </nav>
    </header>
    <script>
        // Listen for when the tab is closed to destroy the session
        window.onbeforeunload = function() {
            <?php
            session_unset();
            session_destroy();
            ?>
        };

        // Toggle the dropdown menu visibility when the profile button is clicked
        document.getElementById("profile-button").addEventListener("click", function(event) {
            const dropdown = document.getElementById("profile-dropdown");
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
            event.stopPropagation(); // Prevent the event from bubbling up
        });

        // Close the dropdown menu if clicking outside
        document.addEventListener("click", function(event) {
            const dropdown = document.getElementById("profile-dropdown");
            const profileButton = document.getElementById("profile-button");
            if (!profileButton.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = "none";
            }
        });
         // Add confirmation for logout
    document.querySelector('.logout-btn').addEventListener('click', function(event) {
        // Show confirmation dialog
        const confirmed = confirm("Are you sure you want to log out?");
        
        // If user clicks 'Cancel', prevent the form from submitting
        if (!confirmed) {
            event.preventDefault(); // Prevent the logout form submission
        }
    });
    </script>

    <!--==================== MAIN ====================-->
    <main class="main">
        <!--==================== HOME ====================-->
        <section class="home">
            <div class="home__container container">
                <div class="home__content">
                    <div class="home__data">
                        <h3 class="home__subtitle">A LIFETIME EXPERIENCE</h3>
                        <h1 class="home__title">
                            Camping Events <br>
                            To Remember
                        </h1>
                        <p class="home__description">Camp anywhere anytime without hassle and enjoy.</p>
                        <a href="location.php" class="home__button">Explore Locations</a>
                    </div>
                    <img src="../profile-icons/bird-1.svg" alt="image" class="home__bird-1">
                    <img src="../profile-icons/bird-2.svg" alt="image" class="home__bird-2">
                </div>
                <div class="home__images">
                    <img src="../profile-icons/img-4.svg" alt="image" class="home__img-4">
                    <img src="../profile-icons/img-3.svg" alt="image" class="home__img-3">
                    <img src="../profile-icons/img-2.svg" alt="image" class="home__img-2">
                    <img src="../profile-icons/img-1.svg" alt="image" class="home__img-1">
                </div>
            </div>
        </section>
    </main>
    
    <!--=============== GSAP ===============-->
    <script src="../js/gsap.min.js"></script>

    <!--=============== MAIN JS ===============-->
    <script src="../js/main.js"></script>

<script>// Function to fetch notifications from the server
function fetchNotifications() {
    fetch('../notification/fetch_notifications.php') // Make a request to fetch notifications
        .then(response => response.json()) // Parse the response as JSON
        .then(data => {
            const notificationList = document.getElementById('notification-list');
            const notificationCount = document.getElementById('notification-count');

            // Clear the previous notifications in the list
            notificationList.innerHTML = "";

            // Update the notification badge if there are unread notifications
            if (data.unreadCount > 0) {
                notificationCount.textContent = data.unreadCount; // Set the number of unread notifications
                notificationCount.style.display = "inline-block"; // Show the badge
            } else {
                notificationCount.style.display = "none"; // Hide badge if no unread notifications
            }

            // Loop through each notification and display them in the list
            data.notifications.forEach(notification => {
                const li = document.createElement('li');
                // Add the notification message and its creation date to the list item
                li.textContent = `${notification.message} - ${new Date(notification.created_at).toLocaleString()}`;
                notificationList.appendChild(li); // Append the list item to the notification list
            });
        });
}

// Function to toggle the visibility of the notification modal
function toggleNotifications() {
    const modal = document.getElementById('notification-modal');
    // Toggle the modal visibility between "block" and "none"
    modal.style.display = modal.style.display === "block" ? "none" : "block";

    // Mark notifications as read when the modal is opened
    if (modal.style.display === "block") {
        markNotificationsAsRead(); // Call function to mark notifications as read
    }
}

// Function to mark notifications as read by making a POST request to the server
function markNotificationsAsRead() {
    fetch('../notification/mark_notifications_read.php', { method: 'POST' }) // Send a POST request to mark notifications as read
        .then(() => fetchNotifications()); // Refresh notifications after marking them as read
}

// Automatically fetch notifications when the page loads
window.onload = fetchNotifications;
</script>

</body>
</html>
