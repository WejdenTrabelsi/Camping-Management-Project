<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login/index.php");
    exit;
}

// Handle edit option (This should be in manage_option.php)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_option'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (!empty($name) && !empty($description) && !empty($price)) {
        try {
            $stmt = $conn->prepare("UPDATE extra_options SET name = ?, description = ?, price = ? WHERE id = ?");
            $stmt->execute([$name, $description, $price, $id]);

            $_SESSION['success_message'] = "Option updated successfully!";
            header("Location: manage_option.php");
            exit;
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Error updating option: " . $e->getMessage();
            header("Location: manage_option.php");
            exit;
        }
    } else {
        $_SESSION['error_message'] = "Please fill in all fields.";
        header("Location: manage_option.php");
        exit;
    }
}


?>

