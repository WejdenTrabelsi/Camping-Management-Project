<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Camping Adventures</title>
    <link rel="stylesheet" href="../style/signup.css">
    <link rel="stylesheet" href="../style/index.css">
    <style>   
    body {
  background: url('home%20page%20yahya/assets/img/signup-background.jpg') no-repeat;
  background-size: cover;
  background-position: center;
}
</style>
</head>
<body>
    <div class="form-container">
        <div class="form-logo">
            <img src="../profile-icons/logo.svg" alt="Camping Adventures">
        </div>
        <h1 class="form-title">Welcome Back</h1>
        
        <?php if (isset($_SESSION['login_message'])): ?>
            <div class="message <?= strpos($_SESSION['login_message'], 'success') ? 'success' : 'error' ?>">
                <?= $_SESSION['login_message'] ?>
            </div>
            <?php unset($_SESSION['login_message']); ?>
        <?php endif; ?>

        <form action="login_process.php" method="POST">
            <div class="input-box">
                <input type="text" name="username" placeholder="Username" required>
                <img src="../profile-icons/user.png" alt="image" class="icon">  
            </div>
            <div class="input-box">
                <input type="password" name="password" placeholder="Password" required>
                <img src="../profile-icons/lock.png" alt="image" class="icon">
               
            </div>
            <button type="submit">Log In</button>
        </form>
        
        <div class="signup-link">
            Don't have an account? <a href="../clt_pages/sign up/signup.php">Sign Up</a>
        </div>
        
    </div>
    <script src="../js/gsap.min.js"></script>

    <script>
        gsap.from('.form-logo',1.2, {opacity: 0, y:-50, delay: .3})
        gsap.from('.form-container',1.2, {opacity: 0, y:-50, delay: .1})
        gsap.from('.form-title',1.2, {opacity: 0, y:-50, delay: .5})
        gsap.from('.input-box',1.2, {opacity: 0, y:-50, delay: .7})
        gsap.from('button',1.2, {opacity: 0, y:-50, delay: 1})
        gsap.from('.signup-link',1.2, {opacity: 0, y:-50, delay: 1})
    </script>
</body>
</html>