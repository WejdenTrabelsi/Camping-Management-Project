<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include '../db/db.php';

// 2. Validate inputs
$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
$name = trim($_POST['name'] ?? '');
$message = $_POST['message'] ?? '';

// Validation checks
$errors = [];
if (strlen($username) < 4) $errors[] = "Username must be at least 4 characters";
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format";

if (!empty($errors)) {
    $_SESSION['signup_message'] = implode("<br>", $errors);
    header("Location: ../clt_pages/sign up/signup.php");
    exit();
}


// 4. Insert message
try {
    // Ensure input data is validated and sanitized as needed (e.g., using filter_var() or prepared statements)
    
    // Default state is 'new'
    $state = 'new';

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO client_messages 
        (name, email, message, state) 
        VALUES (?, ?, ?, ?)");

    // Bind parameters to the prepared statement
    $stmt->bindParam(1, $name);
    $stmt->bindParam(2, $email);
    $stmt->bindParam(3, $message);
    $stmt->bindParam(4, $state); // State is always 'new'

    // Execute the statement and check for errors
    if (!$stmt->execute()) {
        throw new Exception("Execute failed");
    }

    $_SESSION['contact_message'] = "Your message has been successfully sent!";
    header("Location: ../clt_pages/homepage.php");
    exit();
} catch (Exception $e) {
    $errorInfo = $conn->errorInfo() ?? ['No DB info available'];
    error_log("CONTACT MESSAGE ERROR: " . $e->getMessage() . " | DB Error: " . print_r($errorInfo, true));

    $_SESSION['contact_message'] = "Error: " . $e->getMessage() . " | DB Error: " . $errorInfo[2];
    header("Location: ../clt_pages//homepage.php");
    exit();
}
