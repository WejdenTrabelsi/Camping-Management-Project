<?php
session_start();
require_once 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Fetch all locations with creator info
$query = $conn->query("
    SELECT l.*, u.username as creator
    FROM locations l
    LEFT JOIN users u ON l.created_by = u.id
    ORDER BY l.created_at DESC
");
$locations = $query->fetchAll(PDO::FETCH_ASSOC);

// Fetch the updated locations
$stmt = $conn->query("SELECT * FROM locations");
$locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Fetch all discounts
$query = $conn->query("SELECT * FROM discounts");
$discounts = $query->fetchAll(PDO::FETCH_ASSOC);

// Function to fetch discount by location_id
function getDiscountByLocationId($discounts, $location_id) {
    foreach ($discounts as $discount) {
        if ($discount['location_id'] == $location_id) {
            return $discount; // Return the matching discount
        }
    }
    return null; // Return null if no matching discount is found
}

// Fetch all locations along with their extra options
$query = "
    SELECT l.*, GROUP_CONCAT(e.name ORDER BY e.name) AS extra_options
    FROM locations l
    LEFT JOIN location_options lo ON lo.location_id = l.id
    LEFT JOIN extra_options e ON e.name = lo.option_name
    GROUP BY l.id
";
$stmt = $conn->prepare($query);
$stmt->execute();
$locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Locations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        .location-card {
            transition: transform 0.3s;
            height: 100%;
            
        }
        .location-card:hover {
            transform: translateY(-15px);
        }
        .amenity-icon {
            font-size: 1.2rem;
            margin-right: 5px;
        }
        body {
            background-image: url('home page yahya/assets/img/admin-background3.jpg'); /* Add the image URL */
            background-size: cover; /* Make sure the image covers the whole page */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            
            }
        .sidebar {
            background: linear-gradient(to top, #19274A, #425C97);
            min-height: 100vh;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.8); 
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 600;
            padding: 1rem;
        }
        .sidebar .nav-link:hover {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .sidebar .nav-link.active {
            color: #fff;
        }
        
        .badge-pending {
            background-color: #f6c23e;
            border-radius:5px;
        }
        .badge-active {
            background-color: #1cc88a;
            border-radius:5px;
        }
        .badge-deactivated {
            background-color: #e74a3b;
            border-radius:5px;

        }
        .add-location-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            font-size: 24px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        /* Profile Button (located at top-right corner) */
        .profile-dropdown-container {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .profile-button {
    background: none;
    cursor: pointer;
    width: 60px; /* Keep the button bigger */
    height: 60px; /* Keep the button bigger */
    padding: 0;
    border-radius: 50%; /* Make it circular */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transform: translate(-5px, -5px); /* Slightly move it left and down */
    border: 10px solid   #425C97;
}
.profile-button:hover {
    box-shadow: 0 0 15px 5px rgba(118, 156, 229, 0.7); /* Glowing border */
}

.profile-icon {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
}
.profile-icon:hover{
    filter:brightness(1.5);
    box-shadow: 0 0 15px rgba(255, 255, 255, 0.8);
}



        /* Profile Dropdown Menu */
        .profile-dropdown {
    display: none; /* Hidden by default */
    position: absolute;
    top: 50px; /* Position below the button */
    right: 0;
    background-color: white;
    padding: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    min-width: 200px;
    text-align: center;
    border: 2px solid black;
    z-index: 1050; /* Ensures the dropdown is above other elements */
}

        .profile-dropdown p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .logout-btn {
            padding: 10px;
            background: linear-gradient(to top, #19274A, #425C97); /* Apply the gradient */
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
        }

        .logout-btn:hover {
            background:linear-gradient(to top, #19274A, #425C97);
        }
        .card{   
            background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));backdrop-filter:blur(5px);
  border: 2px solid rgb(255, 255, 255);
  backdrop-filter: blur(20px);
  color: white;
  border-radius: 20px;
  text-align: center;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
  font-weight:600;
  font-size:20px;
  margin-bottom:5px;
  top:-50px; 
  margin-bottom: 0 !important;
    padding-bottom: -20px !important;  
}

hr {
    border: 1px solid white; /* White color and 1px width */
     
}
h1 {
    color: white;
     
}
.bg-primary {
    background-color: #4060A1 !important;  /* Change to orange-red */
}
.btn-outline-danger{
    color:rgb(190, 37, 37) !important;
}
.btn-outline-danger:hover{
    color:rgb(255, 255, 255) !important;
    background-color:rgb(190, 37, 37) !important;
}
.btn-outline-primary{
    color:rgb(0, 86, 172) !important;
}
.btn-outline-primary:hover{
    color:rgb(255, 255, 255) !important;
    background-color:rgb(0, 86, 172) !important; 
}
#add-button {
    background: none;
    cursor: pointer;
    width: 60px; /* Keep the button bigger */
    height: 60px; /* Keep the button bigger */
    padding: 0;
    border-radius: 50%; /* Make it circular */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transform: translate(-5px, -5px); /* Slightly move it left and down */
    border: 10px solid   #425C97;
    position: relative;
    top: -20px;   /* Moves the button upwards */
    left: -70px; /* Moves the button to the left */
}

    </style>
</head>
<body>
<div class="container-fluid">
        <div class="row">
          <!-- Sidebar -->
<div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
    <div class="position-sticky pt-3">
        <div class="text-center mb-4">
            <h4 class="text-white">Admin Panel</h4>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="admin_dashboard.php" >
                    <i class="fas fa-fw fa-tachometer-alt"></i> Dashboard
                </a>
            </li><hr/>

            <li class="nav-item">
                <a class="nav-link" href="locations.php" style="background-color: rgba(25, 39, 74, 0.33);border-radius:10px;">
                    <i class="fas fa-fw fa-map-marker-alt"></i> Locations
                </a>
            </li>

            <!-- Add the Extra Options link -->
            <li class="nav-item">
                <a class="nav-link" href="manage_option.php">
                    <i class="fas fa-fw fa-cogs"></i> Extra Options
                </a>
            </li><hr/>

            <li class="nav-item">
                <a class="nav-link" href="admin-messages.php">
                    <i class="fas fa-fw fa-envelope"></i> Client Messages
                </a>
            </li>
        </ul>
    </div>
</div>


            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1>Locations</h1>
                    <!-- Floating Add Button -->
                    <button class="add-button" id="add-button" style="background-color:#425C97;">
                    <a href="add_location.php"><img src="home page yahya/assets/img/add.png" alt="Profile Icon" class="profile-icon" style="filter:invert(1);"></a>
                    
                        </button>
                     <!-- Profile Dropdown Button -->
                     <div class="profile-dropdown-container">
                        <button class="profile-button" id="profile-button">
                            <img src="home page yahya/assets/img/admin-icon.png" alt="Profile Icon" class="profile-icon">
                        </button>
                        
                        <!-- Dropdown Menu -->
                        <div class="profile-dropdown" id="profile-dropdown">
                            <p id="username-display"><?php echo $_SESSION['username']; ?></p>
                            <form action="logout.php" method="post">
                                <button type="submit" name="logout" class="logout-btn">Logout</button>
                            </form>
                        </div>
                    </div>
                </div>

<!-- Location Cards -->
<div class="row mb-4">
    <?php foreach ($locations as $location): ?>
        <div class="col-md-4 mb-n4">
            <div class="border-left-primary h-50 py-5">
                <div class="col">
                    <div class="card location-card shadow-sm">
                        <?php if ($location['image_path']): ?>
                            <div style="position: relative; display: inline-block;">
                                <img src="<?= htmlspecialchars($location['image_path']) ?>" class="card-img-top" style="height: 250px; object-fit: fill; object-position: center; border-top-left-radius:19px; border-top-right-radius:19px; border: 1px solid rgb(255, 255, 255); margin-top:-0.01rem;">
                                
                                <?php 
                                $discount = getDiscountByLocationId($discounts, $location['id']);
                                if ($discount): ?>
                                    <img src="home page yahya/assets/img/discount banner.png" style="position: absolute; top: -18px; left: -3px; width: 150px;">
                                    <div style="position: absolute; bottom: 190px; left: -3px; width: 150px; font-weight:600; font-family:open sans;">
                                        <?= htmlspecialchars($discount['discount_value']) ?><span>%</span>
                                    </div>
                                    <div style="position: absolute; bottom: 170px; left: -3px; width: 150px; font-weight:600; font-family:open sans;">OFF</div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="bg-secondary text-white d-flex align-items-center justify-content-center" style="height: 180px;">
                                <i class="fas fa-map-marker-alt fa-3x"></i>
                            </div>
                        <?php endif; ?>
                        <hr style="margin-top: 0; margin-bottom: 1px;"/>

                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h5 class="card-title"><?= htmlspecialchars($location['name']) ?></h5>
                                <span class="badge bg-primary" style="color: white; font-size: 18px; padding: 5px 10px;"><?= ucfirst($location['type']) ?></span>
                            </div><hr/>

                            <p class="card-text">
                                <small class="text-muted">
                                    <i class="fas fa-user-friends me-1" style="color:white;"></i>
                                    <span class="capacity" style="color:white;">Capacity: <?= $location['capacity'] ?> people</span>
                                </small><hr/>
                            </p>
                            <i class="fas fa-file-alt"></i>
                            <p class="card-text"><?= htmlspecialchars($location['description']) ?></p><hr/>
                            <div class="mb-3 me-4">
                                <?php if ($location['electricity']): ?>
                                    <span class="text-success me-3">
                                         <i class="fas fa-bolt amenity-icon" style="color:rgb(252, 197, 33);"></i> <span class="electricity" style="color:rgb(252, 197, 33);">Electricity</span>
                                    </span>     
                                <?php endif; ?>
                                <?php if ($location['electricity'] && $location['water']): ?>
                                    <span class="separator" style="margin-left: 1px; margin-right: 19px; color:white;">|</span>
                                <?php endif; ?>
                                <?php if ($location['water']): ?>
                                    <span class="text-info">
                                        <i class="fas fa-tint amenity-icon"></i> Water
                                    </span>
                                <?php endif; ?>
                            </div>
                            <?php if ($location['electricity'] || $location['water']): ?>
                                <hr/>
                            <?php endif; ?>                   

                            <!-- Display Extra Options -->
                            <div class="mb-3">
                                <strong>Extra Options: </strong>
                                <?php 
                                    // Convert extra options from string to array
                                    $extra_options = !empty($location['extra_options']) ? explode(',', $location['extra_options']) : [];
                                    
                                    if (!empty($extra_options)): ?>
                                        <ul>
                                            <?php foreach ($extra_options as $option): ?>
                                                <li><?= htmlspecialchars(trim($option)) ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php else: ?>
                                        <span>No extra options available</span>
                                    <?php endif; ?>
                            </div>

                            <div class="d-flex justify-content-between align-items-center">
                                <span class="text-primary fw-bold">
                                    <i class="fas fa-money-bill-wave amenity-icon" style="color:rgb(39, 168, 84);"></i> <span class="money" style="color:rgb(39, 168, 84);">  $<?= number_format($location['price'], 2) ?>/night</span>
                                </span>
                                <div class="btn-group">
                                    <a href="edit_location.php?id=<?= $location['id'] ?>" class="btn btn-sm btn-outline-primary" style="top:-0.5px; border-top-right-radius:0px; border-bottom-right-radius:0px;">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="delete_location.php?id=<?= $location['id'] ?>" class="btn btn-sm btn-outline-danger" style="border-top-left-radius:0px; border-bottom-left-radius:0px;" onclick="return confirm('Delete this location?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </div><hr style="margin-bottom:1px;"/>
                        </div>
                        <div class="foot mb-4">
                            <small class="text-muted">
                                 <span class="added by" style="color:white">Added by <?= htmlspecialchars($location['creator'] ?? 'System') ?> on 
                                <?= date('M d, Y', strtotime($location['created_at'])) ?></span>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    
    <script>
       // Toggle the dropdown menu visibility when the profile button is clicked
document.getElementById("profile-button").addEventListener("click", function(event) {
    const dropdown = document.getElementById("profile-dropdown");
    dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    event.stopPropagation(); // Prevent the event from bubbling up
});

// Close the dropdown menu if clicking outside
document.addEventListener("click", function(event) {
    const dropdown = document.getElementById("profile-dropdown");
    const profileButton = document.getElementById("profile-button");
    if (!profileButton.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.style.display = "none";
    }
});

// Add confirmation for logout
document.querySelector('.logout-btn').addEventListener('click', function(event) {
    // Show confirmation dialog
    const confirmed = confirm("Are you sure you want to log out?");
    
    // If user clicks 'Cancel', prevent the form from submitting
    if (!confirmed) {
        event.preventDefault();
    }
});

    </script>
     <script src="home page yahya/assets/js/gsap.min.js"></script>

<script>
    gsap.from('.sidebar',1.2, {opacity: 1, x:-300, delay: 0})
    gsap.from('.col',1, {opacity: 0, y:-50, delay: .5})
</script>

</body>
</html>