<?php
session_start();
require_once 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Fetch all locations with creator info
$query = $conn->query("
    SELECT l.*, u.username as creator 
    FROM locations l
    LEFT JOIN users u ON l.created_by = u.id
    ORDER BY l.created_at DESC
");
$locations = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Locations</title>
    
    <style>
        .location-card {
            transition: transform 0.3s;
            height: 100%;
        }
        .location-card:hover {
            transform: translateY(-5px);
        }
        .amenity-icon {
            font-size: 1.2rem;
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-map-marked-alt me-2"></i> Camping Locations</h2>
            <a href="add_location.php" class="btn btn-primary">
                <i class="fas fa-plus me-1"></i> Add Location
            </a>
        </div>

        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php foreach ($locations as $location): ?>
            <div class="col">
                <div class="card location-card shadow-sm">
                    <?php if ($location['image_path']): ?>
                    <img src="<?= htmlspecialchars($location['image_path']) ?>" class="card-img-top" style="height: 180px; object-fit: cover;">
                    <?php else: ?>
                    <div class="bg-secondary text-white d-flex align-items-center justify-content-center" style="height: 180px;">
                        <i class="fas fa-map-marker-alt fa-3x"></i>
                    </div>
                    <?php endif; ?>
                    
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h5 class="card-title"><?= htmlspecialchars($location['name']) ?></h5>
                            <span class="badge bg-primary"><?= ucfirst($location['type']) ?></span>
                        </div>
                        
                        <p class="card-text">
                            <small class="text-muted">
                                <i class="fas fa-user-friends me-1"></i>
                                Capacity: <?= $location['capacity'] ?> people
                            </small>
                        </p>
                        
                        <p class="card-text"><?= htmlspecialchars($location['description']) ?></p>
                        
                        <div class="mb-2">
                            <?php if ($location['electricity']): ?>
                            <span class="text-success me-3">
                                <i class="fas fa-bolt amenity-icon"></i> Electricity
                            </span>
                            <?php endif; ?>
                            <?php if ($location['water']): ?>
                            <span class="text-info">
                                <i class="fas fa-tint amenity-icon"></i> Water
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-primary fw-bold">
                                $<?= number_format($location['price'], 2) ?>/night
                            </span>
                            <div class="btn-group">
                                <a href="edit_location.php?id=<?= $location['id'] ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="delete_location.php?id=<?= $location['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this location?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent">
                        <small class="text-muted">
                            Added by <?= htmlspecialchars($location['creator'] ?? 'System') ?> on 
                            <?= date('M d, Y', strtotime($location['created_at'])) ?>
                        </small>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>