<?php
include 'db.php';

$id = $_GET['id'];
$conn->query("UPDATE client_messages SET state='seen' WHERE id=$id");

header("Location: admin-messages.php");
?>
