<?php
session_start();
require_once 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Get current user ID
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->execute([$_SESSION['username']]);
$user = $stmt->fetch();

// Retrieve form data
$location_name = $_POST['name'];
$location_type = $_POST['type'];
$location_price = $_POST['price'];
$location_capacity = $_POST['capacity'];
$location_electricity = isset($_POST['electricity']) ? 1 : 0;
$location_water = isset($_POST['water']) ? 1 : 0;
$location_description = $_POST['description'];

// Handle image upload
$image_path = null;
if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true); // Create directory if it doesn't exist
    }

    $image_name = time() . "_" . basename($_FILES['image']['name']);
    $image_path = $upload_dir . $image_name;

    // Move the uploaded file to the target directory
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
        echo "Error uploading image.";
        exit;
    }
}

// Insert location into the database
$stmt = $conn->prepare("INSERT INTO locations (name, type, price, capacity, electricity, water, description, image_path, created_by) 
                        VALUES (:name, :type, :price, :capacity, :electricity, :water, :description, :image_path, :created_by)");

// Bind all the parameters
$stmt->bindParam(':name', $location_name);
$stmt->bindParam(':type', $location_type);
$stmt->bindParam(':price', $location_price);
$stmt->bindParam(':capacity', $location_capacity);
$stmt->bindParam(':electricity', $location_electricity);
$stmt->bindParam(':water', $location_water);
$stmt->bindParam(':description', $location_description);
$stmt->bindParam(':image_path', $image_path);
$stmt->bindParam(':created_by', $user['id']); // Bind the user ID

// Execute insert query
if ($stmt->execute()) {
    $location_id = $conn->lastInsertId();

    // Insert selected extra options
    if (!empty($_POST['extra_options'])) {
        $extra_options = $_POST['extra_options'];

        foreach ($extra_options as $option_id) {
            // Get option name
            $stmt_opt = $conn->prepare("SELECT name FROM extra_options WHERE id = :option_id");
            $stmt_opt->bindParam(':option_id', $option_id);
            $stmt_opt->execute();
            $option = $stmt_opt->fetch(PDO::FETCH_ASSOC);

            if ($option) {
                // Insert into location_options
                $stmt_insert_opt = $conn->prepare("INSERT INTO location_options (location_id, option_name) 
                                                   VALUES (:location_id, :option_name)");
                $stmt_insert_opt->bindParam(':location_id', $location_id);
                $stmt_insert_opt->bindParam(':option_name', $option['name']);
                $stmt_insert_opt->execute();
            }
        }
    }

    // Redirect after success
    header("Location: locations.php");
    exit;
} else {
    echo "Error: Could not save location.";
}
?>
