<?php
session_start();
header('Content-Type: application/json');
include('../db.php');

$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    echo json_encode([
        'unreadCount' => 0,
        'notifications' => []
    ]);
    exit;
}

// Fetch unread notifications from the database
$stmt = $conn->prepare("SELECT id, message, created_at FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];
while ($row = $result->fetch_assoc()) {
    $notifications[] = [
        'message' => $row['message'],
        'created_at' => $row['created_at']
    ];
}

// Output JSON with unread count
echo json_encode([
    'unreadCount' => count($notifications),
    'notifications' => $notifications
]);
?>
