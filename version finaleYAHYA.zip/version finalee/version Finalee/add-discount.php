<?php
session_start();
require_once 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
// Get location ID from query parameter
if (!isset($_GET['id'])) {
    header("Location: locations.php");
    exit;   
}


$location_id = $_GET['id'];
$_SESSION['location_id'] = $location_id; // Set session location_id


?>


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Discount</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background-image: url('home page yahya/assets/img/admin-background3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        label {
            color: white;
            font-weight: bold;
        }
        .container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .discount-buttons {
            display: flex;
            border: 2px solid white;
            border-radius: 25px;
            overflow: hidden;
        }
        .discount-btn {
            flex: 1;
            padding: 10px 15px;
            text-align: center;
            font-weight: bold;
            color: white;
            border: none;
            cursor: pointer;
            transition: background 0.3s ease, color 0.3s ease;
        }
        /* Colors: Darker shades for lower percentages, brighter for higher */
        .discount-btn:nth-child(6) { background-color: #2c3e50; } /* 10% */
        .discount-btn:nth-child(5) { background-color: #34495e; } /* 20% */
        .discount-btn:nth-child(4) { background-color: #3d566e; } /* 30% */
        .discount-btn:nth-child(3) { background-color: #4a6882; } /* 40% */
        .discount-btn:nth-child(2) { background-color: #5780a0; } /* 50% */
        .discount-btn:nth-child(1) { background-color: #689ac3; } /* 60% */
        
        /* Hover Effect */
        .discount-btn:hover, .discount-btn.active {
            background-color: white;
            color: #2c3e50;
        }

        /* First and Last Button Rounded Edges */
        .discount-btn:first-child {
            border-top-left-radius: 20px;
            border-bottom-left-radius: 20px;
        }
        .discount-btn:last-child {
            border-top-right-radius: 20px;
            border-bottom-right-radius: 20px;
        }

        /* Hidden input to store selected discount */
        input[name="discount"] {
            display: none;
        }
        .condition-container {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 10px;
            border: 2px solid white;
            backdrop-filter: blur(5px);
            color: white;
            margin-top: 15px;
        }
        .toggle-container {
            display: flex;
            align-items: center;
            border: 1px solid white;
            border-radius: 25px;
            padding: 5px;
            cursor: pointer;
            width: 180px;
            justify-content: space-between;
        }
        .toggle-btn {
            flex: 1;
            text-align: center;
            padding: 5px;
            border-radius: 20px;
            transition: 0.3s;
            cursor: pointer;
        }
        .active-male { background: #4a90e2; color: white; }
        .active-female { background: #e24aa9; color: white; }
        .active-any { background: #f39c12; color: white; }
        .age-range-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .age-range { width: 45%; }
        .condition-tags {
            margin-top: 10px;
        }
        .condition-tag {
            background: rgba(255, 255, 255, 0.3);
            padding: 5px 10px;
            border-radius: 20px;
            margin: 5px;
            display: inline-flex;
            align-items: center;
        }
        .condition-tag button {
            border: none;
            background: none;
            color: white;
            margin-left: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container py-4">
    <div class="card shadow" style="background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57)); backdrop-filter:blur(5px); border:2.5px solid white; border-radius:20px;">
        <div class="card-header bg-primary text-white" style="background:linear-gradient(to top, #19274A, #425C97) !important; border-bottom:2.5px solid white; border-top-right-radius:20px; border-top-left-radius:20px;">
            <h4 class="mb-0"><i class="fas fa-tags me-1"></i> Add New Discount</h4>
        </div>
        <div class="card-body" style="background: linear-gradient(to top, rgba(25, 39, 74, 0), rgba(66, 91, 151, 0))">
            
            <form action="save-discount.php" method="POST">
            <input type="hidden" name="location_id" value="<?php echo $location_id; ?>">
                <label for="discount"> Discount Value:</label>

                <!-- Discount Buttons -->
                <div class="discount-buttons">
                    <button type="button" class="discount-btn" data-value="10%">10%</button>
                    <button type="button" class="discount-btn" data-value="20%">20%</button>
                    <button type="button" class="discount-btn" data-value="30%">30%</button>
                    <button type="button" class="discount-btn" data-value="40%">40%</button>
                    <button type="button" class="discount-btn" data-value="50%">50%</button>
                    <button type="button" class="discount-btn" data-value="60%">60%</button>
                </div>

                <!-- Hidden Input to Store Selected Discount -->
                <input type="hidden" name="discount" id="discount-value" value="10">

                <!-- Age Range -->
                <div class="condition-container" >
                    <label for="age" style="justify-content:center;display: flex;">Age Range:</label>
                    <div class="age-range-container">
                        <input type="range" id="min-age" name="min-age" min="18" max="100" value="18" class="age-range">
                        <input type="range" id="max-age" name="max-age" min="18" max="100" value="100" class="age-range">
                    </div>
                    <div>
                        <span>Min Age: <span id="min-age-value">18</span></span> 
                        <span >Max Age: <span id="max-age-value">100</span></span>
                    </div>
                </div>

                <!-- Gender Toggle -->
                <div class="condition-container mt-3">
                    <label>Gender:</label>
                    <div class="toggle-container" style="padding: 0;">
                        <div class="toggle-btn active-any" id="any-btn"style="border-top-right-radius:0px;border-bottom-right-radius:0px;">Any</div>
                        <div class="toggle-btn" id="male-btn" style="border-radius:0px;">Male</div>
                        <div class="toggle-btn" id="female-btn"style="border-top-left-radius:0px;border-bottom-left-radius:0px;">Female</div>
                    </div>
                    <input type="hidden" name="gender" id="gender" value="any">
                </div>
                <div class="d-flex justify-content-center">
                    <div class="text-center">
                        <label for="discount-duration" class="form-label">Discount Duration (in Days):</label>
                        <input type="number" id="discount-duration" name="discount-duration" value="1" min="1" max="365" class="form-control mx-auto" style="width: 80px;">
                    </div>
                </div>




                <!-- Hidden Tags for Selected Conditions -->
                <div class="condition-tags" id="condition-tags">
                    <!-- Tags will be added dynamically -->
                </div>
                <div>
                    
                <div class="mt-4 text-center">
                <div style="display: flex; justify-content: center; gap: 10px;">
    <!-- Cancel Button on the Left -->
    <a href="locations.php" class="btn btn-secondary me-2" style="background:linear-gradient(to top, #19274A, #425C97) !important; border:2px solid white;">
        <i class="fas fa-times me-1"></i> Cancel
    </a>

    <!-- Save Discount Button -->
   
        <!-- Your form data here (if any) -->
        <button type="submit" class="btn btn-secondary me-2" style="background:linear-gradient(to top, #19274A, #425C97) !important; border:2px solid white;">
            <i class="fas fa-save me-1"></i> Save Discount
        
    
</div>

</div>

    </div>
            </form>

        </div>
    </div>
</div>

<script>
    // Handle button selection for discount
    document.querySelectorAll(".discount-btn").forEach(button => {
        button.addEventListener("click", function() {
            // Remove 'active' class from all buttons
            document.querySelectorAll(".discount-btn").forEach(btn => btn.classList.remove("active"));
            
            // Add 'active' class to selected button
            this.classList.add("active");

            // Update hidden input with selected value
            document.getElementById("discount-value").value = this.dataset.value;
        });
    });

    // Handle age range selection
    document.getElementById("min-age").addEventListener("input", function() {
        document.getElementById("min-age-value").textContent = this.value;
        updateConditionTags(); // Update the condition tag when the slider value changes
    });

    document.getElementById("max-age").addEventListener("input", function() {
        document.getElementById("max-age-value").textContent = this.value;
        updateConditionTags(); // Update the condition tag when the slider value changes
    });

    // Handle gender toggle
    document.getElementById("any-btn").addEventListener("click", function() {
        document.getElementById("any-btn").classList.add("active-any");
        document.getElementById("male-btn").classList.remove("active-male");
        document.getElementById("female-btn").classList.remove("active-female");
        document.getElementById("gender").value = "any";
        updateConditionTags();
    });

    document.getElementById("male-btn").addEventListener("click", function() {
        document.getElementById("male-btn").classList.add("active-male");
        document.getElementById("female-btn").classList.remove("active-female");
        document.getElementById("any-btn").classList.remove("active-any");
        document.getElementById("gender").value = "male";
        updateConditionTags();
    });

    document.getElementById("female-btn").addEventListener("click", function() {
        document.getElementById("female-btn").classList.add("active-female");
        document.getElementById("male-btn").classList.remove("active-male");
        document.getElementById("any-btn").classList.remove("active-any");
        document.getElementById("gender").value = "female";
        updateConditionTags();
    });

    // Update condition tags
    function updateConditionTags() {
        const gender = document.getElementById("gender").value;
        const minAge = document.getElementById("min-age").value;
        const maxAge = document.getElementById("max-age").value;

        const conditionTags = [];
        conditionTags.push(`Age: ${minAge}-${maxAge}`);
        conditionTags.push(`Gender: ${gender}`);

        // Update the displayed tags
        const conditionTagsContainer = document.getElementById("condition-tags");
        conditionTagsContainer.innerHTML = ''; // Clear existing tags

        // Add the updated tags
        conditionTags.forEach(tag => {
            const tagDiv = document.createElement("div");
            tagDiv.classList.add("condition-tag");
            tagDiv.innerHTML = `${tag} <button onclick="removeTag(this)"></button>`;
            conditionTagsContainer.appendChild(tagDiv);
        });
    }

    // Remove condition tag
    function removeTag(button) {
        button.parentElement.remove();
        // Reset the corresponding input based on the tag removed
        const tagText = button.parentElement.textContent.replace(' x', '');
        const [key, value] = tagText.split(': ');
        if (key === 'Age') {
            const [min, max] = value.split('-');
            document.getElementById("min-age").value = min;
            document.getElementById("max-age").value = max;
        } else if (key === 'Gender') {
            document.getElementById("gender").value = value.toLowerCase();
        }
        updateConditionTags(); // Re-update the condition tags after removal
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="home page yahya/assets/js/gsap.min.js"></script>
<script>
        gsap.from('a',1.2, {opacity: 0, y:-50, delay: .3})
        gsap.from('.container',1.2, {opacity: 0, y:-50, delay: .1})
        gsap.from('.condition-container',1.2, {opacity: 0, y:-50, delay: .5})
        gsap.from('.input-box',1.2, {opacity: 0, y:-50, delay: .7})
        gsap.from('input',1.2, {opacity: 0, y:-50, delay: 1.2})
        gsap.from('button',1.2, {opacity: 0, y:-50, delay: .3})   
    </script>
</body>
</html>
