<?php
session_start();
require_once 'db.php';  // Make sure this includes the correct DB connection

// Check if admin is logged in and has the correct role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Fetch extra options (name, description, price)
$stmt = $conn->query("SELECT id, name, description, price FROM extra_options");
$options = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission for adding new extra option
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_option'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (!empty($name) && !empty($description) && !empty($price)) {
        // Insert the new extra option into the database
        $stmt = $conn->prepare("INSERT INTO extra_options (name, description, price) VALUES (?, ?, ?)");
        $stmt->execute([$name, $description, $price]);

        // Redirect to reload the page and display the new entry
        echo "<script>
                window.location.href = 'manage_option.php';
              </script>";
        exit;
    } else {
        $error_message = "Please fill in all fields.";
    }
}

// Handle edit option
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_option'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (!empty($name) && !empty($description) && !empty($price)) {
        // Update the extra option in the database
        $stmt = $conn->prepare("UPDATE extra_options SET name = ?, description = ?, price = ? WHERE id = ?");
        $stmt->execute([$name, $description, $price, $id]);

        // Redirect to reload the page
        echo "<script>
                window.location.href = 'manage_option.php';
              </script>";
        exit;
    } else {
        $error_message = "Please fill in all fields.";
    }
}

// Handle delete option
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_option_id'])) {
    $id = $_POST['delete_option_id'];

    // Delete the extra option from the database
    $stmt = $conn->prepare("DELETE FROM extra_options WHERE id = ?");
    $stmt->execute([$id]);

    // Redirect to reload the page and reflect the deletion
    echo "<script>
            window.location.href = 'manage_option.php';
          </script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Extra Options</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: url('home page yahya/assets/img/admin-background3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .sidebar {
            background: linear-gradient(to top, #19274A, #425C97);
            min-height: 100vh;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.8); 
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 600;
            padding: 1rem;
        }
        .sidebar .nav-link:hover {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .sidebar .nav-link.active {
            color: #fff;
        }
        .add-location-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            font-size: 24px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        .card {
            background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));
            backdrop-filter:blur(3px);
            border: 2px solid rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(20px);
            color: white;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            font-weight:600;
            font-size:20px;
        }
        hr {
            border: 1px solid white;
        }
        h1 {
            color: white;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
<div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
    <div class="position-sticky pt-3">
        <div class="text-center mb-4">
            <h4 class="text-white">Admin Panel</h4>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="admin_dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i> Dashboard
                </a>
            </li><hr/>

            <li class="nav-item">
                <a class="nav-link" href="locations.php">
                    <i class="fas fa-fw fa-map-marker-alt"></i> Locations
                </a>
            </li>

            <!-- Add the Extra Options link -->
            <li class="nav-item">
                <a class="nav-link" href="manage_option.php" style="background-color: rgba(25, 39, 74, 0.33);border-radius:10px;">
                    <i class="fas fa-fw fa-cogs"></i> Extra Options
                </a>
            </li><hr/>

            <li class="nav-item">
                <a class="nav-link" href="admin-messages.php">
                    <i class="fas fa-fw fa-envelope"></i> Client Messages
                </a>
            </li>
        </ul>
    </div>
</div>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1>Manage Extra Options</h1>
                </div>

                <!-- Extra Options Table -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h3 class="m-0">Extra Options</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Option Name</th>
                                        <th>Description</th>
                                        <th>Price</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($options as $option): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($option['name']) ?></td>
                                        <td><?= htmlspecialchars($option['description']) ?></td>
                                        <td><?= htmlspecialchars($option['price']) ?></td>
                                        <td>
                                            <!-- Edit button -->
                                            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editOptionModal<?= $option['id'] ?>">Edit</button>
                                            <!-- Delete button -->
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="delete_option_id" value="<?= $option['id'] ?>">
                                                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this option?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Add Extra Option Button (Floating Action Button) -->
                <div class="add-location-btn-container">
                    <button class="add-location-btn" data-bs-toggle="modal" data-bs-target="#addOptionModal">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>

                <!-- Modal for Adding Extra Option -->
                <div class="modal fade" id="addOptionModal" tabindex="-1" aria-labelledby="addOptionModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addOptionModalLabel">Add Extra Option</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <?php if (isset($error_message)): ?>
                                    <div class="alert alert-danger"><?= $error_message ?></div>
                                <?php endif; ?>
                                <form method="POST">
                                    <div class="mb-3">
                                        <label for="name" class="form-label">Option Name</label>
                                        <input type="text" class="form-control" id="name" name="name" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="description" class="form-label">Description</label>
                                        <textarea class="form-control" id="description" name="description" required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="price" class="form-label">Price</label>
                                        <input type="number" class="form-control" id="price" name="price" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary" name="add_option">Add Option</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Modal for Editing Extra Option -->
                <?php foreach ($options as $option): ?>
                    <div class="modal fade" id="editOptionModal<?= $option['id'] ?>" tabindex="-1" aria-labelledby="editOptionModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editOptionModalLabel">Edit Extra Option</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="POST">
                                        <input type="hidden" name="id" value="<?= $option['id'] ?>">
                                        <div class="mb-3">
                                            <label for="name" class="form-label">Option Name</label>
                                            <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($option['name']) ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="description" class="form-label">Description</label>
                                            <textarea class="form-control" id="description" name="description" required><?= htmlspecialchars($option['description']) ?></textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label for="price" class="form-label">Price</label>
                                            <input type="number" class="form-control" id="price" name="price" value="<?= htmlspecialchars($option['price']) ?>" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="edit_option">Save Changes</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
