<?php
session_start();
require_once 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Get location ID
if (!isset($_GET['id'])) {
    header("Location: locations.php");
    exit;
}

// Fetch location data
$stmt = $conn->prepare("SELECT * FROM locations WHERE id = ?");
$stmt->execute([$_GET['id']]);
$location = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$location) {
    header("Location: locations.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Location</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
         body {
            background-image: url('home page yahya/assets/img/admin-background3.jpg'); /* Add the image URL */
            background-size: cover; /* Make sure the image covers the whole page */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            
            }
         label{
            color:white;
         }
       
    .container {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

    </style>
</head>
<body>
    <div class="container py-4">
        <div class="card shadow" style="background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));backdrop-filter:blur(5px);border:2.5px solid white;border-radius:20px;" >
            <div class="card-header bg-primary text-white" style="background:linear-gradient(to top, #19274A, #425C97) !important;border-bottom:2.5px solid white;border-top-right-radius:20px;border-top-left-radius:20px;">
                <h4 class="mb-0"><i class="fas fa-edit me-2"></i> Edit Location</h4>
            </div>
            <div class="card-body">
                <form action="update_location.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?= $location['id'] ?>">
                    <input type="hidden" name="current_image" value="<?= $location['image_path'] ?>">

                    <div class="mb-3" >
                        <?php if ($location['image_path']): ?>
                        <label class="form-label" style="display: block;text-align: center;margin-bottom:-10px;font-size:25px;font-weight:600;">Current Image</label><br>
                        <img src="<?= htmlspecialchars($location['image_path']) ?>" class="img-thumbnail mb-2" style="max-height: 200px; display: block; margin: 0 auto;">
                        <?php endif; ?>
                        <label for="image" class="form-label" style="display: block;text-align: center;margin-top:15px;"><?= $location['image_path'] ? 'Replace Image' : 'Upload Image' ?></label>
                        <input class="form-control" type="file" id="image" name="image" accept="image/*">
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="name" class="form-label">Location Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($location['name']) ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="type" class="form-label">Location Type</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="tent" <?= $location['type'] == 'tent' ? 'selected' : '' ?>>Tent Spot</option>
                                <option value="caravan" <?= $location['type'] == 'caravan' ? 'selected' : '' ?>>Caravan Spot</option>
                                <option value="chalet" <?= $location['type'] == 'chalet' ? 'selected' : '' ?>>Chalet</option>
                                <option value="rv" <?= $location['type'] == 'rv' ? 'selected' : '' ?>>RV Spot</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="price" class="form-label">Price per night ($)</label>
                            <input type="number" class="form-control" id="price" name="price" min="0" step="0.01" value="<?= $location['price'] ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label for="capacity" class="form-label">Maximum Capacity</label>
                            <input type="number" class="form-control" id="capacity" name="capacity" min="1" value="<?= $location['capacity'] ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Amenities</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="electricity" name="electricity" value="1" <?= $location['electricity'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="electricity">
                                    <i class="fas fa-bolt me-1"style="color:rgb(252, 197, 33);"></i> <span class="electricity" style="color:rgb(252, 197, 33);">Electricity</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="water" name="water" value="1" <?= $location['water'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="water">
                                    <i class="fas fa-tint me-1"style="color:#10B6DD;"></i><span class="water" style="color:#10B6DD;"> Water</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($location['description']) ?></textarea>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="locations.php" class="btn btn-secondary me-2" style="background:linear-gradient(to top, #19274A, #425C97) !important; border:2px solid white;">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                        <a href="add-discount.php?id=<?= $location['id'] ?>" class="btn btn-secondary me-2" style="background:linear-gradient(to top, #19274A, #425C97) !important; border:2px solid white;">
    <i class="fas fa-tags me-1"></i> Add discount
</a>

                        <button type="submit" class="btn btn-primary" style="background:linear-gradient(to top, #19274A, #425C97) !important; border:2px solid white;">
                            <i class="fas fa-save me-1"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="home page yahya/assets/js/gsap.min.js"></script>
    <script>
    gsap.from('.container',1.2, {opacity: 0, y:-50, delay: .2})
    gsap.from('input',1.2, {opacity: 0, y:-50, delay: .7})
    gsap.from('img',1.2, {opacity: 0, y:-50, delay: .7})
    gsap.from('label',1.2, {opacity: 0, y:-50, delay: .4})
    gsap.from('textarea',1.2, {opacity: 0, y:-50, delay: .7})
    gsap.from('select',1.2, {opacity: 0, y:-50, delay: .7})
    gsap.from('button',1.2, {opacity: 0, y:-50, delay: .9})
    gsap.from('a',1.2, {opacity: 0, y:-50, delay: .9})
</script>
</body>
</html>