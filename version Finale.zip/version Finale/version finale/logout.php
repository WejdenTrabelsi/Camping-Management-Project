<?php
session_start();
session_unset();
session_destroy();
header("Location: home page yahya/homepage.php"); // Redirect to homepage after logout
exit();
?>