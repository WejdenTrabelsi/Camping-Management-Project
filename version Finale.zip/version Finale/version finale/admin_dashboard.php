<?php
session_start();
include 'db.php';

// Check if admin is logged in and activated
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit;
}

// Check if user is an admin and account is active
$stmt = $conn->prepare("SELECT status FROM users WHERE username = ? AND role = 'admin'");
$stmt->execute([$_SESSION['username']]);
$user = $stmt->fetch();

if (!$user || $user['status'] != 'active') {
    header("Location: index.php");
    exit;
}
// Fetch all clients
$query = $conn->query("SELECT * FROM users WHERE role='client'");
$clients = $query->fetchAll(PDO::FETCH_ASSOC);

// Count client statuses
$totalClients = count($clients);
$pendingClients = 0;
$activeClients = 0;

foreach ($clients as $client) {
    if ($client['status'] == 'pending') $pendingClients++;
    if ($client['status'] == 'active') $activeClients++;
}

// Fetch locations count
try {
    $locationsQuery = $conn->query("SELECT COUNT(*) as count FROM locations");
    $locationsCount = $locationsQuery->fetch(PDO::FETCH_ASSOC)['count'];
} catch (PDOException $e) {
    $locationsCount = 0; // Default to 0 if table doesn't exist
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: url('home page yahya/assets/img/admin-background3.jpg'); /* Add the image URL */
            background-size: cover; /* Make sure the image covers the whole page */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            
            }
        .sidebar {
            background: linear-gradient(to top, #19274A, #425C97);
            min-height: 100vh;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.8); 
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 600;
            padding: 1rem;
        }
        .sidebar .nav-link:hover {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .sidebar .nav-link.active {
            color: #fff;
        }
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        .badge-pending {
            background-color: #f6c23e;
            border-radius:5px;
        }
        .badge-active {
            background-color: #1cc88a;
            border-radius:5px;
        }
        .badge-deactivated {
            background-color: #e74a3b;
            border-radius:5px;

        }
        .add-location-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            font-size: 24px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        /* Profile Button (located at top-right corner) */
        .profile-dropdown-container {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .profile-button {
    background: none;
    cursor: pointer;
    width: 60px; /* Keep the button bigger */
    height: 60px; /* Keep the button bigger */
    padding: 0;
    border-radius: 50%; /* Make it circular */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transform: translate(-5px, -5px); /* Slightly move it left and down */
    border: 10px solid   #425C97;
}

.profile-icon {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
}

.profile-icon:hover{
    filter:brightness(1.5);
    box-shadow: 0 0 15px rgba(255, 255, 255, 0.8);
}


        /* Profile Dropdown Menu */
        .profile-dropdown {
    display: none; /* Hidden by default */
    position: absolute;
    top: 50px; /* Position below the button */
    right: 0;
    background-color: white;
    padding: 10px;
    
    border-radius: 5px;
    min-width: 200px;
    text-align: center;
    border: 2px solid black;
    z-index: 1050; /* Ensures the dropdown is above other elements */
}

        .profile-dropdown p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .logout-btn {
            padding: 10px;
            background: linear-gradient(to top, #19274A, #425C97); /* Apply the gradient */
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
        }

        .logout-btn:hover {
            background:linear-gradient(to top, #19274A, #425C97);
        }
        .card{   
  background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));backdrop-filter:blur(3px);
  border: 2px solid rgba(255, 255, 255, 0.5);
  backdrop-filter: blur(20px);
  color: white;
  border-radius: 10px;
  text-align: center;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
  font-weight:600;
  font-size:20px;
}
hr {
    border: 1px solid white; /* White color and 1px width */
     
}
h1 {
    color: white;
     
}
</style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h4 class="text-white">Admin Panel</h4>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" style="background-color: rgba(25, 39, 74, 0.33);border-radius:10px;">
                                <i class="fas fa-fw fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li><hr/>

                        <li class="nav-item">
                            <a class="nav-link" href="locations.php">
                                <i class="fas fa-fw fa-map-marker-alt"></i> Locations
                            </a>
                        </li><hr/>
                        <li class="nav-item">
                            <a class="nav-link" href="admin-messages.php">
                            <i class="fas fa-fw fa-envelope"></i> client messages
                            </a>
                        </li>
                        
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1>Dashboard</h1>
                     <!-- Profile Dropdown Button -->
                     <div class="profile-dropdown-container">
                        <button class="profile-button" id="profile-button">
                            <img src="home page yahya/assets/img/admin-icon.png" alt="Profile Icon" class="profile-icon">
                        </button>
                        
                        <!-- Dropdown Menu -->
                        <div class="profile-dropdown" id="profile-dropdown">
                            <p id="username-display"><?php echo $_SESSION['username']; ?></p>
                            <form action="logout.php" method="post">
                                <button type="submit" name="logout" class="logout-btn">Logout</button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs">
                                            Total Clients</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalClients ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs">
                                            Pending Clients</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $pendingClients ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs">
                                            Active Clients</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $activeClients ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Client Table -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h3 class="m-0">Client Accounts</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($clients as $client): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($client['username']) ?></td>
                                        <td><?= htmlspecialchars($client['email']) ?></td>
                                        <td>
                                            <span class="badge badge-<?= strtolower($client['status']) ?>">
                                                 <?= ucfirst($client['status']) ?>
                                             </span>
                                        </td>                                         
                                        <td>
                                            <?php if ($client['status'] == 'pending' || $client['status'] == 'deactivated'): ?>
                                                <a href="activate_client.php?id=<?= $client['id'] ?>" class="btn btn-sm btn-success">
                                                    <i class="fas fa-check"></i> Activate
                                                </a>
                                            <?php endif; ?>
                                            <?php if ($client['status'] == 'active'): ?>
                                                <a href="deactivate_client.php?id=<?= $client['id'] ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-times"></i> Deactivate
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    
    <script>
       // Toggle the dropdown menu visibility when the profile button is clicked
document.getElementById("profile-button").addEventListener("click", function(event) {
    const dropdown = document.getElementById("profile-dropdown");
    dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    event.stopPropagation(); // Prevent the event from bubbling up
});

// Close the dropdown menu if clicking outside
document.addEventListener("click", function(event) {
    const dropdown = document.getElementById("profile-dropdown");
    const profileButton = document.getElementById("profile-button");
    if (!profileButton.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.style.display = "none";
    }
});

// Add confirmation for logout
document.querySelector('.logout-btn').addEventListener('click', function(event) {
    // Show confirmation dialog
    const confirmed = confirm("Are you sure you want to log out?");
    
    // If user clicks 'Cancel', prevent the form from submitting
    if (!confirmed) {
        event.preventDefault();
    }
});

    </script>
     <script src="home page yahya/assets/js/gsap.min.js"></script>

<script>
    gsap.from('.sidebar',1.2, {opacity: 1, x:-300, delay: 0})
    gsap.from('.card',1.2, {opacity: 0, y:-50, delay: .5})
</script>

</body>
</html>