<?php
session_start();
require_once '../../db/db.php'; // Assuming this file contains the database connection

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login/index.php"); // Redirect to login page if not logged in as admin
    exit;
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize the data from the form
    $discount_value = filter_var($_POST['discount'], FILTER_SANITIZE_NUMBER_INT);
    $min_age = filter_var($_POST['min-age'], FILTER_SANITIZE_NUMBER_INT);
    $max_age = filter_var($_POST['max-age'], FILTER_SANITIZE_NUMBER_INT);
    $gender = filter_var($_POST['gender'], FILTER_SANITIZE_STRING);
    $discount_duration = filter_var($_POST['discount-duration'], FILTER_SANITIZE_NUMBER_INT); // Expecting number of days
    
    // Retrieve location_id from the session or POST (depending on how it's passed)
    $location_id = isset($_SESSION['location_id']) ? $_SESSION['location_id'] : (isset($_POST['location_id']) ? $_POST['location_id'] : null);

    // Validate inputs
    if (empty($discount_value) || empty($min_age) || empty($max_age) || empty($gender) || empty($discount_duration) || empty($location_id)) {
        echo "All fields are required.";
        exit;
    }

    // Calculate the expiry date by adding the discount_duration (in days) to today's date
    $today = new DateTime();  // Get today's date
    $expiryDate = clone $today; // Clone today to avoid modifying the original DateTime object
    $expiryDate->modify("+$discount_duration days"); // Add the duration to today's date
    
    // Format the expiry date for database insertion
    $expiryDateFormatted = $expiryDate->format('Y-m-d'); // Format as YYYY-MM-DD

    // Prepare the SQL query to insert the data into the 'discounts' table
    $sql = "INSERT INTO discounts (discount_value, min_age, max_age, gender, discount_duration, location_id, expiry_date) 
            VALUES (:discount_value, :min_age, :max_age, :gender, :discount_duration, :location_id, :expiry_date)";

    // Prepare the statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind the parameters to the SQL query
        $stmt->bindParam(':discount_value', $discount_value, PDO::PARAM_INT);
        $stmt->bindParam(':min_age', $min_age, PDO::PARAM_INT);
        $stmt->bindParam(':max_age', $max_age, PDO::PARAM_INT);
        $stmt->bindParam(':gender', $gender, PDO::PARAM_STR);
        $stmt->bindParam(':discount_duration', $discount_duration, PDO::PARAM_INT);
        $stmt->bindParam(':location_id', $location_id, PDO::PARAM_INT);
        $stmt->bindParam(':expiry_date', $expiryDateFormatted, PDO::PARAM_STR);

        // Fetch location name
        $sql_location = "SELECT name FROM locations WHERE id = :location_id";
        $stmt_location = $conn->prepare($sql_location);
        $stmt_location->bindParam(':location_id', $location_id, PDO::PARAM_INT);
        $stmt_location->execute();
        $location = $stmt_location->fetch(PDO::FETCH_ASSOC);
        $location_name = $location ? htmlspecialchars($location['name']) : "Unknown Location";

        // Construct the discount message
        $discount_message = "We are happy to inform you that the location $location_name has a $discount_value% discount under the conditions that you are";
        if ($gender !== "any") {
            $discount_message .= " a $gender and";
        }
        $discount_message .= " between the ages of $min_age and $max_age.";
        $discount_message .= " This discount expires on $expiryDateFormatted.";

        // Insert the message into the notifications table
        $sql_notification = "INSERT INTO notifications (message, created_at) VALUES (:message, NOW())";
        $stmt_notification = $conn->prepare($sql_notification);
        $stmt_notification->bindParam(':message', $discount_message, PDO::PARAM_STR);

        // Execute the notification query
        if ($stmt_notification->execute()) {
            echo "Notification saved successfully.";
        } else {
            echo "Error saving notification: " . $stmt_notification->errorInfo()[2];
        }

        // Execute the main insert statement
        if ($stmt->execute()) {
            // Redirect to locations.php after successful insertion
            header("Location: ../locations/locations.php");
            exit;
        } else {
            // Error occurred, display error message
            echo "Error: " . $stmt->errorInfo()[2]; 
        }

        // Close the statement
        $stmt->closeCursor();
    } else {
        // Error preparing the SQL query
        echo "Error preparing the query.";
    }
} else {
    // If not a POST request, redirect back to locations.php
    header("Location: ../locations.php");
    exit;
}

// Close the database connection
$conn = null;
?>
