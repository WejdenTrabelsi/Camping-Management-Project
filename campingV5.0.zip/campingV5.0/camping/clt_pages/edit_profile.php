<?php
session_start();
include '../db/db.php'; // Include your database connection

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "Please log in to edit your profile.";
    header("Location: login.php");
    exit();
}

// Retrieve client information
$user_id = $_SESSION['user_id'];
try {
    $stmt = $conn->prepare("SELECT email, username, gender, age, role FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) {
        $_SESSION['message'] = "User not found.";
        header("Location: profile.php");
        exit();
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $_SESSION['message'] = "Error fetching user data. Please try again later.";
    header("Location: profile.php");
    exit();
}

// Handle form submission for profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? ''; // New password field
    $gender = $_POST['gender'] ?? 'female'; // Default to female
    $age = $_POST['age'] ?? '';

    $errors = [];

    // Validate email, username, and age
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format";
    if (strlen($username) < 4) $errors[] = "Username must be at least 4 characters";
    if (!empty($password) && strlen($password) < 8) $errors[] = "Password must be at least 8 characters";
    if (!in_array($gender, ['male', 'female'])) $errors[] = "Invalid gender selection";
    if (!is_numeric($age) || $age < 18 || $age > 100) $errors[] = "Age must be between 18 and 100";

    // If there are validation errors, show them
    if (!empty($errors)) {
        $_SESSION['message'] = implode("<br>", $errors);
    } else {
        // If password is provided, hash it
        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            // Update with new password
            $stmt = $conn->prepare("UPDATE users SET email = ?, username = ?, password = ?, gender = ?, age = ? WHERE id = ?");
            $stmt->execute([$email, $username, $hashedPassword, $gender, $age, $user_id]);
        } else {
            // Update without changing the password
            $stmt = $conn->prepare("UPDATE users SET email = ?, username = ?, gender = ?, age = ? WHERE id = ?");
            $stmt->execute([$email, $username, $gender, $age, $user_id]);
        }

        // After updating, refresh the session data with the new profile information
        $stmt = $conn->prepare("SELECT email, username, gender, age FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $updatedUser = $stmt->fetch();

        // Update session variables
        $_SESSION['email'] = $updatedUser['email'];
        $_SESSION['username'] = $updatedUser['username'];
        $_SESSION['gender'] = $updatedUser['gender'];
        $_SESSION['age'] = $updatedUser['age'];

        $_SESSION['message'] = "Profile updated successfully.";
    }

    header("Location: homepage.php");
    exit();
}
?>
