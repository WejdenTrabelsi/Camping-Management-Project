<?php
require_once '../db/db.php';

header('Content-Type: application/json');

if (empty($_POST['location_id']) || empty($_POST['start_date']) || empty($_POST['end_date'])) {
    echo json_encode(['available' => false, 'message' => 'All fields are required']);
    exit;
}

try {
    $stmt = $conn->prepare("
        SELECT COUNT(*) 
        FROM reservations 
        WHERE location_id = ? 
        AND status IN ('pending', 'confirmed')
        AND (
            (start_date BETWEEN ? AND ?) 
            OR (end_date BETWEEN ? AND ?)
            OR (? BETWEEN start_date AND end_date)
            OR (? BETWEEN start_date AND end_date)
        )
    ");
    $stmt->execute([
        $_POST['location_id'],
        $_POST['start_date'],
        $_POST['end_date'],
        $_POST['start_date'],
        $_POST['end_date'],
        $_POST['start_date'],
        $_POST['end_date']
    ]);

    $count = $stmt->fetchColumn();
    echo json_encode(['available' => $count == 0, 'message' => $count == 0 ? 'Available' : 'Not available']);
} catch (Exception $e) {
    echo json_encode(['available' => false, 'message' => 'Error checking availability']);
}
?>