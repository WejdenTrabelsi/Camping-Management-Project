<?php
session_start();
require_once '../db/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/index.php");
    exit;
}

// Initialize variables
$location = [];
$extra_options = [];
$services_only = false;
$location_id = $_GET['location_id'] ?? $_POST['location_id'] ?? null;

// Fetch location details if ID is present
if ($location_id) {
    $stmt = $conn->prepare("SELECT * FROM locations WHERE id = ?");
    $stmt->execute([$location_id]);
    $location = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$location) {
        header("Location: locations.php");
        exit;
    }
    
    // Fetch options related to this location
    $stmt = $conn->prepare("SELECT * FROM location_options WHERE location_id = ?");
    $stmt->execute([$location_id]);
    $extra_options = $stmt->fetchAll(PDO::FETCH_ASSOC);
}



// Calculate total price
$total_price = 0;
if (isset($_POST['services'])) {
    foreach ($_POST['services'] as $service) {
        $service_data = json_decode($service, true);
        $total_price += $service_data['price'];
    }
}

// If not services only, add location price
if (!$services_only && $location) {
    $total_price += $location['price'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make a Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: url('../profile-icons/admin-background3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        label, h1, .price-display {
            color: white;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.7);
        }
        .container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .form-section {
            width: 100%;
            max-width: 650px;
        }
        .card {
            background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));
            backdrop-filter: blur(5px);
            border: 2.5px solid white;
            border-radius: 20px;
        }
        .card-header {
            background: linear-gradient(to top, #19274A, #425C97) !important;
            color: white;
            border-bottom: 2.5px solid white;
            border-top-right-radius: 20px;
            border-top-left-radius: 20px;
        }
        .form-check-label {
            color: white;
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="card form-section shadow">
        <div class="card-header">
            <h4 class="mb-0">
                <i class="fas fa-calendar-check me-2"></i>
                <?= $services_only ? 'Book Services Only' : 'Reserve ' . htmlspecialchars($location['name'] ?? '') ?>
            </h4>
        </div>
        <div class="card-body">
        <form id="reservationForm" action="process_reservation.php" method="POST">
    <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?>">
    <input type="hidden" name="location_id" value="<?= $location['id'] ?>">
    
    <!-- Date inputs -->
    <div class="mb-3">
        <label for="start_date" class="form-label">Check-in Date</label>
        <input type="date" class="form-control" id="start_date" name="start_date" required min="<?= date('Y-m-d') ?>">
    </div>
    
    <div class="mb-3">
        <label for="end_date" class="form-label">Check-out Date</label>
        <input type="date" class="form-control" id="end_date" name="end_date" required min="<?= date('Y-m-d') ?>">
    </div>



    <!-- Keep payment method -->
    <div class="mb-3">
        <label for="payment_method" class="form-label">Payment Method</label>
        <select class="form-select" id="payment_method" name="payment_method" required>
            <option value="credit_card">Credit Card</option>
            <option value="paypal">PayPal</option>
            <option value="bank_transfer">Bank Transfer</option>
            <option value="cash_on_arrival">Cash on Arrival</option>
        </select>
    </div>

    <!-- Keep price display -->
    <div class="mb-3 price-display">
        <h4>Total Price: $<span id="totalPrice"><?= number_format($total_price, 2) ?></span></h4>
    </div>

    <!-- Update the submit button -->
    <div class="d-flex justify-content-between">
        <button type="submit" class="btn btn-success">
            <i class="fas fa-calendar-check"></i> Confirm Reservation
        </button>
        <a href="locations.php" class="btn btn-secondary">Cancel</a>
    </div>
</form>
        </div>
    </div>
</div>

<!-- Modals remain the same as in your original file -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Calculate total price when services are selected
    document.querySelectorAll('.service-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', calculateTotal);
    });

    function calculateTotal() {
        let total = <?= $services_only ? 0 : $location['price'] ?? 0 ?>;
        
        document.querySelectorAll('.service-checkbox:checked').forEach(checkbox => {
            total += parseFloat(checkbox.dataset.price);
        });
        
        document.getElementById('totalPrice').textContent = total.toFixed(2);
    }

    // Date validation
    document.getElementById('start_date')?.addEventListener('change', function() {
        const startDate = this.value;
        const endDateInput = document.getElementById('end_date');
        endDateInput.min = startDate;
        if (endDateInput.value < startDate) {
            endDateInput.value = '';
        }
    });
</script>
</body>
</html>