<?php
session_start();

require_once '../db/db.php';


// Fetch all locations with creator info
$query = $conn->query("
    SELECT l.*, u.username as creator
    FROM locations l
    LEFT JOIN users u ON l.created_by = u.id
    ORDER BY l.created_at DESC
");
$locations = $query->fetchAll(PDO::FETCH_ASSOC);

// Fetch all discounts
$query = $conn->query("SELECT * FROM discounts");
$discounts = $query->fetchAll(PDO::FETCH_ASSOC);

// Function to fetch discount by location_id
function getDiscountByLocationId($discounts, $location_id) {
    foreach ($discounts as $discount) {
        if ($discount['location_id'] == $location_id) {
            return $discount; // Return the matching discount
        }
    }
    return null; // Return null if no matching discount is found
}

// Fetch all locations along with their extra options
$query = "
    SELECT l.*, GROUP_CONCAT(e.name ORDER BY e.name) AS extra_options
    FROM locations l
    LEFT JOIN location_options lo ON lo.location_id = l.id
    LEFT JOIN extra_options e ON e.name = lo.option_name
    GROUP BY l.id
";
$stmt = $conn->prepare($query);
$stmt->execute();
$locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Locations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        .location-card {
            transition: transform 0.3s;
            height: 100%;
        }
        .location-card:hover {
            transform: translateY(-15px);
        }
        .amenity-icon {
            font-size: 1.2rem;
            margin-right: 5px;
        }
        body {
            background-image: url('../profile-icons/admin-background3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        body, .container-fluid {
            margin: 0;
            padding: 0;
        }
        .badge-pending {
            background-color: #f6c23e;
            border-radius:5px;
        }
        .badge-active {
            background-color: #1cc88a;
            border-radius:5px;
        }
        .badge-deactivated {
            background-color: #e74a3b;
            border-radius:5px;
        }
    
    
        .profile-dropdown {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            min-width: 200px;
            text-align: center;
            border: 2px solid black;
            z-index: 1050;
        }
        .profile-dropdown p {
            font-size: 16px;
            margin-bottom: 10px;
        }
        .logout-btn {
            padding: 10px;
            background: linear-gradient(to top, #19274A, #425C97);
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
        }
        .logout-btn:hover {
            background:linear-gradient(to top, #19274A, #425C97);
        }
        .card {
            background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));
            backdrop-filter: blur(5px);
            border: 2px solid rgb(255, 255, 255);
            color: white;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            font-weight:600;
            font-size:20px;
            margin-bottom:5px;
        }
        hr {
            border: 1px solid white;
        }
        h1 {
            color: white;
        }
        .bg-primary {
            background-color: #4060A1 !important;
        }
        .btn-outline-danger {
            color:rgb(190, 37, 37) !important;
        }
        .btn-outline-danger:hover {
            color:rgb(255, 255, 255) !important;
            background-color:rgb(190, 37, 37) !important;
        }
        .btn-outline-primary {
            color:rgb(0, 86, 172) !important;
        }
        .btn-outline-primary:hover {
            color:rgb(255, 255, 255) !important;
            background-color:rgb(0, 86, 172) !important; 
        }
        #add-button {
            background: none;
            cursor: pointer;
            width: 60px;
            height: 60px;
            padding: 0;
            border-radius: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transform: translate(-5px, -5px);
            border: 10px solid #425C97;
            position: relative;
            top: -20px;
            left: -70px;
        }
        .location-cards-container {
    display: flex;
    justify-content:start;  /* Align items to the left */
    flex-wrap: wrap;
    padding: 0;
    margin: 0;
}

        .location-card-wrapper {
            margin: 20px;
        }
        .location-card-wrapper {
    flex: 0 1 calc(33.33% - 40px); /* 3 per row with spacing */
    display: flex;
    justify-content: center;
}
    </style>
</head>
<body>


<main class=" px-md-4 ">
    <div class=" top-bar d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
        <h1>Locations</h1>
    </div>

    <!-- Location Cards -->
    <div class="location-cards-container">
        <?php foreach ($locations as $location): ?>
            <div class=" location-card-wrapper">
                <div class="card location-card shadow-sm">
                    <?php if ($location['image_path']): ?>
                        <div style="position: relative; display: inline-block;">
                            <img src="<?= htmlspecialchars($location['image_path']) ?>" class="card-img-top" style="height: 250px; object-fit: fill; object-position: center; border-top-left-radius:19px; border-top-right-radius:19px; border: 1px solid rgb(255, 255, 255); margin-top:-0.01rem;">
                            <?php 
                            $discount = getDiscountByLocationId($discounts, $location['id']);
                            if ($discount): ?>
                                <img src="../profile-icons/discount banner.png" style="position: absolute; top: -18px; left: -3px; width: 150px;">
                                <div style="position: absolute; bottom: 190px; left: -3px; width: 150px; font-weight:600; font-family:open sans;">
                                    <?= htmlspecialchars($discount['discount_value']) ?><span>%</span>
                                </div>
                                <div style="position: absolute; bottom: 170px; left: -3px; width: 150px; font-weight:600; font-family:open sans;">OFF</div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="bg-secondary text-white d-flex align-items-center justify-content-center" style="height: 180px;">
                            <i class="fas fa-map-marker-alt fa-3x"></i>
                        </div>
                    <?php endif; ?>
                    <hr style="margin-top: 0; margin-bottom: 1px;"/>
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h5 class="card-title"><?= htmlspecialchars($location['name']) ?></h5>
                            <span class="badge bg-primary" style="color: white; font-size: 18px; padding: 5px 10px;"><?= ucfirst($location['type']) ?></span>
                        </div><hr/>
                        <p class="card-text">
                            <small class="text-muted">
                                <i class="fas fa-user-friends me-1" style="color:white;"></i>
                                <span class="capacity" style="color:white;">Capacity: <?= $location['capacity'] ?> people</span>
                            </small><hr/>
                        </p>
                        <i class="fas fa-file-alt"></i>
                        <p class="card-text"><?= htmlspecialchars($location['description']) ?></p><hr/>
                        <div class="mb-3 me-4">
                            <?php if ($location['electricity']): ?>
                                <span class="text-success me-3">
                                     <i class="fas fa-bolt amenity-icon" style="color:rgb(252, 197, 33);"></i> <span class="electricity" style="color:rgb(252, 197, 33);">Electricity</span>
                                </span>     
                            <?php endif; ?>
                            <?php if ($location['electricity'] && $location['water']): ?>
                                <span class="separator" style="margin-left: 1px; margin-right: 19px; color:white;">|</span>
                            <?php endif; ?>
                            <?php if ($location['water']): ?>
                                <span class="text-info">
                                    <i class="fas fa-tint amenity-icon"></i> Water
                                </span>
                            <?php endif; ?>
                        </div>
                        <?php if ($location['electricity'] || $location['water']): ?>
                            <hr/>
                        <?php endif; ?>                   

                        <div class="mb-3">
                            <strong >Extra Options: </strong>
                            <?php 
                                // Convert extra options from string to array
                                $extra_options = !empty($location['extra_options']) ? explode(',', $location['extra_options']) : [];
                                
                                if (!empty($extra_options)): ?>
                                    <ul>
                                        <?php foreach ($extra_options as $option): ?>
                                            <li><?= htmlspecialchars(trim($option)) ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <span>No extra options available</span>
                                <?php endif; ?>
<!-- Reserve Now Button -->
<a href="reserve.php?location_id=<?= $location['id'] ?>" class="btn btn-success mt-3">
    <i class="fas fa-calendar-check"></i> Reserve Now
</a>
                        </div>

                        <div class="d-flex justify-content-center align-items-center">
                            <span class="text-primary fw-bold center">
                                <i class="fas fa-money-bill-wave amenity-icon" style="color:rgb(71, 236, 129);"></i> <span class="money" style="color:rgb(71, 236, 129);">  $<?= number_format($location['price'], 2) ?>/night</span>
                            </span>
                        </div><hr style="margin-bottom:1px;"/>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <script src="../js/gsap.min.js"></script>

<script>
    
    gsap.from('.location-card-wrapper',1.2, {opacity: 0, y:-50, delay: .7})
    gsap.from('.top-bar',1.2, {opacity: 0, y:-50, delay: .5})
</script>
</body>
</html>
