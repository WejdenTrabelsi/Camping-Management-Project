<?php
session_start();
require_once '../db/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/index.php");
    exit;
}

// Handle cancel reservation if form is submitted
if (isset($_GET['cancel_id'])) {
    $reservation_id = $_GET['cancel_id'];
    
    try {
        // Verify the reservation belongs to the current user
        $stmt = $conn->prepare("SELECT * FROM reservations WHERE id = ? AND user_id = ?");
        $stmt->execute([$reservation_id, $_SESSION['user_id']]);
        $reservation = $stmt->fetch();
        
        if ($reservation) {
            // Update reservation status to cancelled
            $update_stmt = $conn->prepare("UPDATE reservations SET status = 'cancelled' WHERE id = ?");
            $update_stmt->execute([$reservation_id]);
            
            $_SESSION['success'] = "Reservation #$reservation_id has been cancelled successfully!";
            header("Location: my_reservations.php");
            exit;
        } else {
            $_SESSION['error'] = "Reservation not found or you don't have permission to cancel it.";
            header("Location: my_reservations.php");
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Database error: " . $e->getMessage();
        header("Location: my_reservations.php");
        exit;
    }
}

// Get user's reservations
$stmt = $conn->prepare("SELECT r.*, l.name as location_name 
                       FROM reservations r
                       JOIN locations l ON r.location_id = l.id
                       WHERE r.user_id = ?
                       ORDER BY r.start_date DESC");
$stmt->execute([$_SESSION['user_id']]);
$reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Reservations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: url('../profile-icons/admin-background3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
        }
        
        .container {
            padding-top: 80px;
        }
        
        h2 {
            color: white;
            text-shadow: 0 2px 4px rgba(0,0,0,0.5);
            margin-bottom: 30px !important;
        }
        
        .reservation-card {
            background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));
            backdrop-filter: blur(5px);
            border: 2px solid rgba(255, 255, 255, 0.5);
            border-radius: 15px;
            color: white;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            height: 100%;
            margin-bottom: 25px;
            overflow: hidden;
        }
        
        .reservation-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
            border-color: rgba(255, 255, 255, 0.8);
        }
        
        .card-header {
            background: rgba(25, 39, 74, 0.7);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h5 {
            margin: 0;
            font-weight: 600;
            font-size: 1.2rem;
        }
        
        .status-badge {
            font-size: 0.8rem;
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: 600;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .card-body p {
            margin-bottom: 10px;
            font-size: 0.95rem;
        }
        
        .card-body strong {
            color: rgba(255, 255, 255, 0.9);
        }
        
        .btn {
            font-weight: 500;
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 0.9rem;
            transition: all 0.3s;
            width: 100%;
            max-width: 200px;
        }
        
        .btn-danger {
            background-color: rgba(231, 74, 59, 0.8);
            border-color: rgba(255, 255, 255, 0.3);
        }
        
        .btn-danger:hover {
            background-color: rgba(180, 35, 24, 0.9);
            border-color: white;
        }
        
        .alert-info {
            background-color: rgba(25, 39, 74, 0.7);
            border-color: rgba(255, 255, 255, 0.3);
            color: white;
            backdrop-filter: blur(5px);
        }
        
        .alert-link {
            color: #a3c4ff;
            text-decoration: underline;
        }
        
        .alert-link:hover {
            color: white;
        }
        
        /* Animation for cards */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .reservation-card {
            animation: fadeIn 0.5s ease forwards;
        }
        
        /* Success/Error message styling */
        .alert-message {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            min-width: 300px;
            text-align: center;
            animation: fadeIn 0.3s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; top: 0; }
            to { opacity: 1; top: 20px; }
        }
    </style>
</head>
<body>
<div class="container py-4">
    <!-- Display success/error messages -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-message alert-dismissible fade show">
            <?= $_SESSION['success'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-message alert-dismissible fade show">
            <?= $_SESSION['error'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <h2 class="mb-4">My Reservations</h2>
    
    <?php if (empty($reservations)): ?>
        <div class="alert alert-info">
            You don't have any reservations yet. <a href="locations.php" class="alert-link">Book now!</a>
        </div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($reservations as $reservation): ?>
                <div class="col-md-6">
                    <div class="card reservation-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><?= htmlspecialchars($reservation['location_name']) ?></h5>
                            <span class="badge bg-<?= $reservation['status'] === 'confirmed' ? 'success' : ($reservation['status'] === 'cancelled' ? 'danger' : 'warning') ?> status-badge">
                                <?= ucfirst($reservation['status']) ?>
                            </span>
                        </div>
                        <div class="card-body">
                            <p><strong>Dates:</strong> <?= date('M j, Y', strtotime($reservation['start_date'])) ?> to <?= date('M j, Y', strtotime($reservation['end_date'])) ?></p>
                            <p><strong>Total Price:</strong> $<?= number_format($reservation['total_price'], 2) ?></p>
                            <div class="d-flex justify-content-center">
                                <?php if ($reservation['status'] === 'confirmed'): ?>
                                    <a href="my_reservations.php?cancel_id=<?= $reservation['id'] ?>" 
                                       class="btn btn-danger"
                                       onclick="return confirm('Are you sure you want to cancel this reservation?')">
                                        <i class="fas fa-times-circle"></i> Cancel Reservation
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Auto-dismiss alerts after 5 seconds
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert-message');
        alerts.forEach(alert => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
</script>
</body>
</html>