<?php
session_start();
require_once '../db/db.php'; // Adjust path as needed

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $user_id = $_POST['user_id'];
    $location_id = $_POST['location_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    
    try {
        // Calculate total price (you'll need to adjust this based on your pricing logic)
        $stmt = $conn->prepare("SELECT price FROM locations WHERE id = ?");
        $stmt->execute([$location_id]);
        $location = $stmt->fetch();
        $price_per_day = $location['price'];
        
        // Calculate number of days
        $datetime1 = new DateTime($start_date);
        $datetime2 = new DateTime($end_date);
        $interval = $datetime1->diff($datetime2);
        $days = $interval->days;
        $total_price = $price_per_day * $days;
        
        // Insert into database
        $stmt = $conn->prepare("
            INSERT INTO reservations (user_id, location_id, start_date, end_date, total_price, status) 
            VALUES (?, ?, ?, ?, ?, 'pending')
        ");
        $stmt->execute([$user_id, $location_id, $start_date, $end_date, $total_price]);
        
        // Redirect to my_reservations.php with success message
        $_SESSION['reservation_success'] = true;
        header("Location: my_reservations.php");
        exit;
        
    } catch (PDOException $e) {
        // Handle error
        $_SESSION['error'] = "Error creating reservation: " . $e->getMessage();
        header("Location: reserve.php?location_id=$location_id");
        exit;
    }
} else {
    header("Location: locations.php");
    exit;
}
?>