<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login/index.php");
    exit;
}

$reservation_id = $_GET['id'] ?? 0;

// Fetch reservation details
$stmt = $conn->prepare("
    SELECT r.*, u.username as client_name, l.name as location_name 
    FROM reservations r
    JOIN users u ON r.user_id = u.id
    JOIN locations l ON r.location_id = l.id
    WHERE r.id = ?
");
$stmt->execute([$reservation_id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reservation) {
    $_SESSION['error'] = "Reservation not found";
    header("Location: admin_dashboard.php");
    exit;
}

// Fetch all locations for dropdown
$locations = $conn->query("SELECT * FROM locations")->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $location_id = $_POST['location_id'];
    $status = $_POST['status'];
    
    try {
        $stmt = $conn->prepare("
            UPDATE reservations 
            SET start_date = ?, end_date = ?, location_id = ?, status = ?
            WHERE id = ?
        ");
        $stmt->execute([$start_date, $end_date, $location_id, $status, $reservation_id]);
        
        $_SESSION['success'] = "Reservation updated successfully";
        header("Location: admin_dashboard.php");
        exit;
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .edit-container {
            max-width: 800px;
            margin: 50px auto;
        }
    </style>
</head>
<body>
<div class="container edit-container">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h4>Edit Reservation #<?= $reservation['id'] ?></h4>
        </div>
        <div class="card-body">
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Client</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($reservation['client_name']) ?>" readonly>
                </div>
                
                <div class="mb-3">
                    <label for="location_id" class="form-label">Location</label>
                    <select class="form-select" id="location_id" name="location_id" required>
                        <?php foreach ($locations as $location): ?>
                            <option value="<?= $location['id'] ?>" <?= $location['id'] == $reservation['location_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($location['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="start_date" class="form-label">Start Date</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" 
                               value="<?= $reservation['start_date'] ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="end_date" class="form-label">End Date</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" 
                               value="<?= $reservation['end_date'] ?>" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="pending" <?= $reservation['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="confirmed" <?= $reservation['status'] == 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
                        <option value="cancelled" <?= $reservation['status'] == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                
                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                    <a href="admin_dashboard.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>