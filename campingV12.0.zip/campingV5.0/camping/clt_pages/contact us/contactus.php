<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Camping Adventures</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../../style/signup.css">
    <style>
         body {
  background: url('../../profile-icons/signup-background.jpg') no-repeat;
  background-size: cover;
  background-position: center;
}
</style>
</head>
<body>
    <style>
        .input-box textarea {
    height: 120px; 
    width:330px;
    background: none;
    border:1px solid rgba(255, 255, 255, 0.7);;
    border-radius:20px;
    color:white;
    padding: 10px 45px 10px 15px;
    font-size:16px;
}
.input-box textarea::placeholder {
    color: rgba(255, 255, 255, 0.7); /* Set placeholder text color to white */
}
.button-container {
    display: flex; /* Aligns children (buttons) in a row */
    gap: 10px; /* Adds space between the buttons */
}

.button-container button {
    padding: 10px 20px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
}
    #clear-btn:hover {
    background-color:rgb(60, 136, 198);; /* Brighter red */
}

#send-btn:hover {
    background-color:rgb(60, 136, 198); /* Brighter green */
}
    </style>
    <div class="form-container">
     <!-- Logo du site -->
        <div class="form-logo">
            <img src="../../profile-icons/logo.svg" alt="Camping Adventures">
        </div>
    <!-- Titre du formulaire -->
        <h1 class="form-title">Get in Touch</h1>
    <!-- Vérifie si un message de session est défini et l'affiche -->
        <?php if (isset($_SESSION['contact_message'])): ?>
            <div class="message <?= strpos($_SESSION['contact_message'], 'success') ? 'success' : 'error' ?>">
                <?= $_SESSION['contact_message'] ?>
            </div>
            <?php unset($_SESSION['contact_message']); ?>
        <?php endif; ?>
    <!-- Formulaire de contact -->
<form action="contact_process.php" method="POST">
    <!-- Champ pour le nom -->
    <div class="input-box">
        <input type="text" name="name" placeholder="Your Name" required>
        <i class='bx bxs-user'></i>
    </div>
    <!-- Champ pour l'email -->
    <div class="input-box">
        <input type="email" name="email" placeholder="Your Email" required>
        <i class='bx bxl-gmail'></i>
    </div>
    <!-- Champ pour le message -->

    <div class="input-box">
      <textarea name="message" placeholder="Your Message" required></textarea>
   
    </div>
    <br/><br/>
    <br/>

    <!-- Conteneur pour les boutons -->
            <div class="button-container">
    <!-- bouton Clear All  -->
        <button type="button" id="clear-btn">Clear All</button>
     <!-- Bouton pour envoyer le message -->

        <form action="contact_process.php" method="POST">
            <button type="submit" id="send-btn">Send</button>
        </form>


    </div>
</form>
    <!-- Lien vers la page d'inscription -->        
        <div class="login-link">
            Want to book a camping trip? <a href="../sign up/signup.php">Sign Up</a>
        </div>
    </div>
     <!-- Inclusion de la bibliothèque GSAP pour les animations -->
    <script src="../../js/gsap.min.js"></script>

    <script>
     //animation
        gsap.from('.form-logo', 1.2, {opacity: 0, y: -50, delay: .3})
        gsap.from('.form-container', 1.2, {opacity: 0, y: -50, delay: 0.1})
        gsap.from('.input-box', 1.2, {opacity: 0, y: -50, delay: 0.7})
        gsap.from('.form-title', 1.2, {opacity: 0, y: -50, delay: 0.5})
        gsap.from('.button-container', 1.2, {opacity: 0, y: -50, delay: .9})
        gsap.from('.login-link', 1.2, {opacity: 0, y: -50, delay: 1.1})

    </script>
    <script>
    // Fonction pour vider les champs du formulaire lorsqu'on click clear all
    document.getElementById("clear-btn").addEventListener("click", function() {
        document.querySelector("form").reset();
    });
</script>

</body>
</html>
