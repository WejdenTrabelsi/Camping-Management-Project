<?php
session_start();

// Retrieve form data
$nom = $_POST['name'];
$email = $_POST['email'];
$messageContent = $_POST['message'];

// Create the full message
$fullMessage = "Nom: " . $nom . "\n" . "Email: " . $email . "\n" . "Message: " . $messageContent;

// Save email in session for later use (optional)
$_SESSION['user_email'] = $email;

// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer-master/src/Exception.php';
require 'PHPMailer/PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer/PHPMailer-master/src/SMTP.php';

// Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();                                            
    $mail->Host       = 'smtp.gmail.com';                     
    $mail->SMTPAuth   = true;                                  
    $mail->Username   = 'trabelsiwejden911@gmail.com';         
    $mail->Password   = 'iwsi iacf hjct jgph';                 
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;          
    $mail->Port       = 465;                                    

    // Recipients
    $mail->setFrom('trabelsiwejden911@gmail.com', 'Camping Adventures');
    $mail->addAddress($email, $nom); // Send to the user who submitted the form

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Your Message has been Received';
    $mail->Body    = nl2br($fullMessage);
    $mail->AltBody = $fullMessage;

    $mail->send();
    echo '📩 Confirmation email sent to your address.';
} catch (Exception $e) {
    echo "❌ Email failed to send. Error: {$mail->ErrorInfo}";
}
?>
