<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login/index.php");
    exit;
}

$reservation_id = $_GET['id'] ?? 0;

// Fetch reservation details
$stmt = $conn->prepare("
    SELECT r.*, u.username as client_name, u.email as client_email, 
           l.name as location_name, l.price as location_price
    FROM reservations r
    JOIN users u ON r.user_id = u.id
    JOIN locations l ON r.location_id = l.id
    WHERE r.id = ?
");
$stmt->execute([$reservation_id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reservation) {
    $_SESSION['error'] = "Reservation not found";
    header("Location: admin_dashboard.php");
    exit;
}

// Fetch reservation services
$stmt = $conn->prepare("
    SELECT eo.name, eo.price 
    FROM reservation_services rs
    JOIN extra_options eo ON rs.service_id = eo.id
    WHERE rs.reservation_id = ?
");
$stmt->execute([$reservation_id]);
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate number of days
$start = new DateTime($reservation['start_date']);
$end = new DateTime($reservation['end_date']);
$days = $start->diff($end)->days;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: url('../profile-icons/admin-background3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
        }
        label, h1, h2, h3, h4, h5, h6, .text-white {
            color: white;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.7);
        }
        .container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .card {
            background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));
            backdrop-filter: blur(5px);
            border: 2.5px solid white;
            border-radius: 20px;
            width: 100%;
            max-width: 900px;
        }
        .card-header {
            background: linear-gradient(to top, #19274A, #425C97) !important;
            color: white;
            border-bottom: 2.5px solid white;
            border-top-right-radius: 20px !important;
            border-top-left-radius: 20px !important;
        }
        .table {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        .table th {
            background-color: rgba(25, 39, 74, 0.7);
            color: white;
        }
        .table td {
            border-color: rgba(255, 255, 255, 0.1);
        }
        .badge {
            font-size: 0.9rem;
            padding: 0.5em 0.75em;
        }
        hr {
            border-color: rgba(255, 255, 255, 0.3);
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-success {
            background-color: #198754;
            border-color: #198754;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card shadow">
        <div class="card-header">
            <h4 class="mb-0"><i class="fas fa-calendar-alt me-2"></i>Reservation Details #<?= $reservation['id'] ?></h4>
        </div>
        <div class="card-body text-white">
            <div class="row mb-3">
                <div class="col-md-6">
                    <h5><i class="fas fa-user me-2"></i>Client Information</h5>
                    <p><strong>Name:</strong> <?= htmlspecialchars($reservation['client_name']) ?></p>
                    <p><strong>Email:</strong> <?= htmlspecialchars($reservation['client_email']) ?></p>
                </div>
                <div class="col-md-6">
                    <h5><i class="fas fa-info-circle me-2"></i>Reservation Status</h5>
                    <span class="badge bg-<?= $reservation['status'] === 'confirmed' ? 'success' : ($reservation['status'] === 'cancelled' ? 'danger' : 'warning') ?>">
                        <?= ucfirst($reservation['status']) ?>
                    </span>
                    <p><strong>Created:</strong> <?= date('M j, Y H:i', strtotime($reservation['created_at'])) ?></p>
                </div>
            </div>
            
            <hr>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <h5><i class="fas fa-map-marker-alt me-2"></i>Location Information</h5>
                    <p><strong>Location:</strong> <?= htmlspecialchars($reservation['location_name']) ?></p>
                    <p><strong>Base Price:</strong> $<?= number_format($reservation['location_price'], 2) ?> per day</p>
                </div>
                <div class="col-md-6">
                    <h5><i class="fas fa-calendar-day me-2"></i>Dates</h5>
                    <p><strong>From:</strong> <?= date('M j, Y', strtotime($reservation['start_date'])) ?></p>
                    <p><strong>To:</strong> <?= date('M j, Y', strtotime($reservation['end_date'])) ?></p>
                    <p><strong>Duration:</strong> <?= $days ?> days</p>
                </div>
            </div>
            
            <hr>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <h5><i class="fas fa-concierge-bell me-2"></i>Additional Services</h5>
                    <?php if (!empty($services)): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Service</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($services as $service): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($service['name']) ?></td>
                                        <td>$<?= number_format($service['price'], 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No additional services selected</p>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <h5><i class="fas fa-users me-2"></i>Participants</h5>
                    <p><strong>Adults:</strong> <?= (int) $reservation['adults'] ?></p>
                    <p><strong>Kids:</strong> <?= (int) $reservation['kids'] ?></p>
                </div>
            </div>
            
            <hr>
            
            <div class="mb-3">
                <h5><i class="fas fa-money-bill-wave me-2"></i>Payment Information</h5>
                <p><strong>Total Price:</strong> $<?= number_format($reservation['total_price'], 2) ?></p>
                <p><strong>Payment Method:</strong> <?= ucwords(str_replace('_', ' ', $reservation['payment_method'])) ?></p>
            </div>
            
            <div class="d-flex justify-content-between">
                <a href="client-reservations.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>Back to reservations</a>
                <div>
                    <a href="edit_reservation.php?id=<?= $reservation['id'] ?>" class="btn btn-primary"><i class="fas fa-edit me-2"></i>Edit</a>
                    <?php if ($reservation['status'] != 'cancelled'): ?>
                        <a href="manage_reservation.php?action=cancel&id=<?= $reservation['id'] ?>" class="btn btn-danger"><i class="fas fa-times me-2"></i>Cancel</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>