<?php
session_start();
require_once '../db/db.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login/index.php");
    exit;
}

$reservation_id = $_GET['id'] ?? 0;

// Fetch reservation details
$stmt = $conn->prepare("
    SELECT r.*, u.username as client_name, l.name as location_name 
    FROM reservations r
    JOIN users u ON r.user_id = u.id
    JOIN locations l ON r.location_id = l.id
    WHERE r.id = ?
");
$stmt->execute([$reservation_id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reservation) {
    $_SESSION['error'] = "Reservation not found";
    header("Location: admin_dashboard.php");
    exit;
}

// Fetch all locations for dropdown
$locations = $conn->query("SELECT * FROM locations")->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $location_id = $_POST['location_id'];
    $status = $_POST['status'];
    $adults = (int)$_POST['adults'];
    $kids = (int)$_POST['kids'];

    // Calculate number of nights
    $nights = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24);
    $nights = max($nights, 1); // Ensure at least 1 night

    // Get the price per night from the selected location
    $stmtPrice = $conn->prepare("SELECT price FROM locations WHERE id = ?");
    $stmtPrice->execute([$location_id]);
    $base_price = $stmtPrice->fetchColumn();

    // Calculate total price based on adults and kids
    $total_price = $nights * ($adults * $base_price + $kids * $base_price);

    try {
        $stmt = $conn->prepare("
            UPDATE reservations 
            SET start_date = ?, end_date = ?, location_id = ?, status = ?, adults = ?, kids = ?, total_price = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $start_date, $end_date, $location_id, $status,
            $adults, $kids, $total_price, $reservation_id
        ]);

        $_SESSION['success'] = "Reservation updated successfully";
        header("Location: client-reservations.php");
        exit;
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: url('../profile-icons/admin-background3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
        }
        label, h1, h2, h3, h4, h5, h6, .text-white {
            color: white;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.7);
        }
        .container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .card {
            background: linear-gradient(to top, rgba(25, 39, 74, 0.55), rgba(66, 91, 151, 0.57));
            backdrop-filter: blur(5px);
            border: 2.5px solid white;
            border-radius: 20px;
            width: 100%;
            max-width: 900px;
        }
        .card-header {
            background: linear-gradient(to top, #19274A, #425C97) !important;
            color: white;
            border-bottom: 2.5px solid white;
            border-top-right-radius: 20px !important;
            border-top-left-radius: 20px !important;
        }
        .form-control, .form-select {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        .form-control:focus, .form-select:focus {
            background-color: rgba(255, 255, 255, 0.3);
            color: white;
            border-color: white;
            box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.25);
        }
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-success {
            background-color: #198754;
            border-color: #198754;
        }
        .alert-danger {
            background-color: rgba(220, 53, 69, 0.8);
            color: white;
            border-color: #dc3545;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card shadow">
        <div class="card-header">
            <h4 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Reservation #<?= $reservation['id'] ?></h4>
        </div>
        <div class="card-body text-white">
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-user me-2"></i>Client</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($reservation['client_name']) ?>" readonly>
                </div>
                
                <div class="mb-3">
                    <label for="location_id" class="form-label"><i class="fas fa-map-marker-alt me-2"></i>Location</label>
                    <select class="form-select" id="location_id" name="location_id" required>
                        <?php foreach ($locations as $location): ?>
                            <option value="<?= $location['id'] ?>" <?= $location['id'] == $reservation['location_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($location['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="adults" class="form-label"><i class="fas fa-user me-2"></i>Adults</label>
                        <input type="number" class="form-control" id="adults" name="adults" step="1"
                               value="<?= $reservation['adults'] ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="kids" class="form-label"><i class="fas fa-child me-2"></i>Kids</label>
                        <input type="number" class="form-control" id="kids" name="kids" 
                               value="<?= $reservation['kids'] ?>" required>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="start_date" class="form-label"><i class="fas fa-calendar-day me-2"></i>Start Date</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" 
                               value="<?= $reservation['start_date'] ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="end_date" class="form-label"><i class="fas fa-calendar-day me-2"></i>End Date</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" 
                               value="<?= $reservation['end_date'] ?>" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="status" class="form-label"><i class="fas fa-info-circle me-2"></i>Status</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="confirmed" <?= $reservation['status'] == 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
                        <option value="cancelled" <?= $reservation['status'] == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                
                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
                    <a href="client-reservations.php" class="btn btn-secondary"><i class="fas fa-times me-2"></i>Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>