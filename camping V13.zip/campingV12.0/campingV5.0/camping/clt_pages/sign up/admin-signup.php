<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Sign Up - Camping Adventures</title>
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="../../style/signup.css">
  <link rel="stylesheet" href="../../style/map-colors.css">
  <style>
    .toggle-container {
        display: flex;
        align-items: center;
        width: 120px;
        background-color: transparent;
        border: 1px solid rgba(255, 255, 255, 0.5);
        border-radius: 25px;
        cursor: pointer;
        position: relative;
        transition: background 0.3s ease-in-out;
    }

    body {
        background: url('../../profile-icons/signup-background.jpg') no-repeat;
        background-size: cover;
        background-position: center;
    }

    .toggle-button {
        width: 50%;
        text-align: center;
        padding: 10px;
        font-size: 18px;
        font-weight: bold;
        transition: all 0.3s ease-in-out;
        color: rgba(0, 0, 0, 0.84);
    }

    .active {
        color: white;
        font-weight: bold;
    }

    .female.active {
        background-color: rgba(249, 116, 213, 0.81);
        border-radius: 25px 0 0 25px;
    }

    .male.active {
        background-color: rgba(98, 211, 255, 0.81);
        border-radius: 0 25px 25px 0;
    }

    .center-container {
        display: flex;
        justify-content: center;
    }

    svg {
        width: 500px;
        height: auto;
    }

    path {
        stroke: black;
        stroke-width: 2;
        cursor: pointer;
        transition: 0.2s;
    }

    #tooltip {
        position: absolute;
        background: white;
        padding: 5px 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        font-size: 14px;
        pointer-events: none;
        display: none;
        z-index: 1000;
    }

    .form-container:nth-of-type(2) {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    #selection-message {
        margin-top: 10px;
        font-weight: bold;
        color: darkgreen;
    }
  </style>
</head>
<body>
<div style="display: flex; gap: 30px;">
  <div class="form-container">
    <div class="form-logo">
      <img src="../../profile-icons/admin-icon.png" alt="Camping Adventures" width="100px">
    </div>

    <h1 class="form-title" style="font-size:31px;">Create Your Admin Account</h1>

    <?php if (isset($_SESSION['signup_message'])): ?>
      <div class="message <?= strpos($_SESSION['signup_message'], 'success') ? 'success' : 'error' ?>">
        <?= $_SESSION['signup_message'] ?>
      </div>
      <?php unset($_SESSION['signup_message']); ?>
    <?php endif; ?>

    <form action="admin_signup_process.php" method="POST" enctype="multipart/form-data">
      <div class="input-box">
        <input type="email" name="email" placeholder="Email Address" required>
        <i class='bx bxl-gmail'></i>
      </div>

      <div class="input-box">
        <input type="text" name="username" placeholder="Username" minlength="4" required>
        <i class='bx bxs-user'></i>
      </div>

      <div class="input-box">
        <input type="password" name="password" placeholder="Password" minlength="8" required>
        <i class='bx bxs-lock-alt'></i>
      </div>

      <!-- Gender -->
      <input type="hidden" name="gender" id="gender-input" value="female">
      <div class="center-container">
        <div class="toggle-container" onclick="toggleGender()">
          <div id="female" class="toggle-button female active"><i class='bx bx-female-sign'></i></div>
          <div id="male" class="toggle-button male"><i class='bx bx-male-sign'></i></div>
        </div>
      </div>
      <br>

      <!-- Age -->
      <div class="age-box">
        <label for="age" style="display: flex; justify-content: center;">Age: <span id="ageValue">18</span></label>
        <input type="range" id="age" name="age" min="18" max="100" value="18" oninput="updateAge(this.value)" required>
      </div>
      <br>

     
      <input type="hidden" id="selected_city_input" name="selected_city">

      <button type="submit">Sign Up</button>
    </form>

    <div class="login-link">
      Already have an account? <a href="../../login/index.php">Log In</a>
    </div>
  </div>

  <div class="form-container">
    <h1 class="form-title" style="font-size:31px;">Choose the city you want to manage</h1>
    <form method="post">
      <?php include("../../tn.svg"); ?>
      <button type="button" onclick="confirmSelection()" style="width:300px;">Confirm Selection</button>
      <p id="selection-message"></p>
    </form>
  </div>
</div>

<div id="tooltip"></div>

<!-- Animations -->
<script src="../../js/gsap.min.js"></script>
<script>
  gsap.from('.form-logo', 1.2, { opacity: 0, y: -50, delay: .3 });
  gsap.from('.form-container', 1.2, { opacity: 0, y: -50, delay: .1 });
  gsap.from('.form-title', 1.2, { opacity: 0, y: -50, delay: .5 });
  gsap.from('.input-box', 1.2, { opacity: 0, y: -50, delay: .7 });
  gsap.from('button', 1.2, { opacity: 0, y: -50, delay: 1.6 });
  gsap.from('.login-link', 1.2, { opacity: 0, y: -50, delay: 1.8 });
</script>

<!-- Gender Toggle -->
<script>
  function toggleGender() {
    let femaleBtn = document.getElementById("female");
    let maleBtn = document.getElementById("male");
    let genderInput = document.getElementById("gender-input");

    if (femaleBtn.classList.contains("active")) {
      femaleBtn.classList.remove("active");
      maleBtn.classList.add("active");
      genderInput.value = "male";
    } else {
      maleBtn.classList.remove("active");
      femaleBtn.classList.add("active");
      genderInput.value = "female";
    }
  }
</script>

<script>
  function updateAge(value) {
    document.getElementById("ageValue").textContent = value;
  }
</script>

<script>
  const paths = document.querySelectorAll("svg path");
  const tooltip = document.getElementById("tooltip");
  const governorates = {
    "TN11": "Tunis", "TN12": "Ariana", "TN13": "Ben Arous", "TN14": "Manubah",
    "TN21": "Nabeul", "TN22": "Zaghouan", "TN23": "Bizerte", "TN31": "Béja",
    "TN32": "Jendouba", "TN33": "Le Kef", "TN34": "Siliana", "TN41": "Kairouan",
    "TN42": "Kassérine", "TN43": "Sidi Bou Zid", "TN51": "Sousse", "TN52": "Monastir",
    "TN53": "Mahdia", "TN61": "Sfax", "TN71": "Gafsa", "TN72": "Tozeur",
    "TN73": "Kebili", "TN81": "Gabès", "TN82": "Médenine", "TN83": "Tataouine"
  };

  paths.forEach(path => {
    path.addEventListener("mouseover", e => {
      const name = governorates[path.id];
      if (name) {
        tooltip.textContent = name;
        tooltip.style.display = "block";
      }
    });

    path.addEventListener("mousemove", e => {
      tooltip.style.left = e.pageX + 15 + "px";
      tooltip.style.top = e.pageY + 15 + "px";
    });

    path.addEventListener("mouseout", () => {
      tooltip.style.display = "none";
    });

    path.addEventListener("click", () => {
      paths.forEach(p => p.classList.remove("active"));
      path.classList.add("active");

      const selectedName = governorates[path.id];
      document.getElementById("selected_city_id").value = path.id;
      document.getElementById("selected_city").value = selectedName;
    });
  });

  function confirmSelection() {
  const activePath = document.querySelector("svg path.active");
  const message = document.getElementById("selection-message");
  const hiddenInput = document.getElementById("selected_city_input");
  const cityName = activePath ? governorates[activePath.id] : '';

  if (cityName) {
    hiddenInput.value = cityName; // ✔ Set the value in the hidden input
    message.textContent = `✅You selected: ${cityName}`;
    message.style.color = "white";
  } else {
    message.textContent = "Please select a city before confirming.";
    message.style.color = "darkred";
  }
}


</script>

</body>
</html>
